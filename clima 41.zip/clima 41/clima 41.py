from time import localtime
from tkinter import Label
import wget
from datetime import date
from datetime import timedelta
import datetime
import os
import sys
import tkinter as tk
from tkinter import *
import time
from tkinter.messagebox import showinfo
from pathlib import Path

ventanaclima = tk.Tk()
ventanaclima.title('Listbox')
ventanaclima.geometry('460x1400+2110+0')
# ventanaclima.wm_attributes('-transparentcolor','Black') #determina que color se hace transparente transparente
ventanaclima.wm_attributes('-alpha', 0.9)
ventanaclima.overrideredirect(1)  # elimina el borde de la ventana
ventanaclima.config(bg='black')  # color de fondo de formulario
ventanaclima.resizable(True, True)
ventanaclima.config()
# ********************************************************************************
def startclima(event):
    global x, y
    x = event.x
    y = event.y


def salirclima(*args):  # sale con spcape
    ventanaclima.destroy()
    ventanaclima.quit()


ventanaclima.bind("<KeyPress-Escape>", salirclima)

# ************************* crea ventan root****************************************
root = tk.Tk()
root.title('Listbox')
root.geometry('500x1000+100+100')
root.wm_attributes('-transparentcolor', 'gray')  # determina que color se hace transparente transparente
root.overrideredirect(1)  # elimina el borde de la ventana
root.config(bg='gray')  # color de fondo de formulario
root.resizable(True, True)
root.config()


# ********************************************************************************
#                       hora
def salir(*args):  # sale con spcape
    root.destroy()
    root.quit()


def obtener_tiempo():  # obtiene la hora
    hora = time.strftime('%H:%M:%S')
    # zona=time.strftime('%Z')
    fecha_formato12 = time.strftime('%a' ' ' '%d' ' ' '%b' ' ' '%Y')

    # *********** Texto formulario 1 hora *******************************************
    texto_hora['text'] = hora
    texto_fecha12['text'] = fecha_formato12
    texto_hora.after(1000, obtener_tiempo)



def start(event):
    global x, y
    x = event.x
    y = event.y


def stop(event):
    global x, y
    x = None
    y = None


def mover(event):  # ********************con este codigo movemos el formulario con el mouse
    global x, y
    deltax = event.x - x
    deltay = event.y - y
    root.geometry("+%s+%s" % (root.winfo_x() + deltax, root.winfo_y() + deltay))
    root.update()


# ****************************** determina los moviento del mouse **************************
root.bind("<ButtonPress-1>", start)
root.bind("<ButtonRelease-1>", stop)
root.bind("<B1-Motion>", mover)
root.bind("<KeyPress-Escape>", salir)
# *****************************************************************************************

#****************************** INICIO CODIGO ACTUALIZACION ******************************

def tiempo():
    global ente
    ente =0
   

    hora = time.strftime('%H:%M:%S')
 
    fecha_formato12 = time.strftime('%a' ' ' '%d' ' ' '%b' ' ' '%Y')

   
    texto_hora['text'] = hora
    texto_fecha12['text'] = fecha_formato12
    texto_hora.after(1000,tiempo)
    
    print(hora)
  
    alarma1= '04:31:00'
    alarma2= '08:00:00'
    alarma3= '12:00:00'
    alarma4= '14:00:00'
    alarma5= '15:30:00'
    alarma6= '17:30:00'
    alarma7= '20:29:00'
   
    if alarma1==hora:
         print("Alarma1:",hora)
         ente=1
         print("valor:",ente)

    if alarma2==hora:
         print("Alarma2",hora)
         ente=2
         print("valor:",ente)

    if alarma3==hora:
         print("Alarma3:",hora)
         ente=3
         print("valor",ente)
        
    if alarma4==hora:
         print("Alarma4",hora)
         ente=4
         print("valor:",ente)

    if alarma5==hora:
         print("Alarma5:",hora)
         ente=5
         print("valor:",ente)
        
    if alarma6==hora:
         print("Alarma6",hora)
         ente=6
         print("valor:",ente)
         
    if alarma7==hora:
         print("Alarma7",hora)
         ente=7
         print("valor:",ente)
         



    if ente ==1 or ente ==2 or ente ==3 or ente ==4 or ente ==5 or ente ==6 or ente ==7:
        print("completado")
        
        obtener_tiempo()

        fechaActual = datetime.datetime.now()  # declara la fecha u hora actual
        print("fechaActual ", fechaActual)

        horaAct1 = datetime.datetime.strftime(fechaActual, '%H%M')  # da el formato para hora de actualizacion

        a = 1
        if (a == 1):  
            fechaActual1 = datetime.datetime.strftime(fechaActual,'20%y%m%d')  # declara el formato para la apertura del archivo
            print("fechaActual1",fechaActual1)
            fechaActual2 = datetime.datetime.strftime(fechaActual,'%d%m20%y')  # declara el formato para name1 osea nombre del zip
            print("fecha actual2", fechaActual2)

            fechaMañana1 = datetime.datetime.strftime(mañana, '20%y%m%d')  # declara el formato para la apertura del archivo
            print("fechamanaña1",fechaMañana1)
            fechaMañana2 = datetime.datetime.strftime(mañana, '%d%m20%y')  # declara el formato para name1 osea nombre del zip

            url = 'https://ssl.smn.gob.ar/dpd/zipopendata.php?dato=tiepre'
            wget.download(url)
            urlpro = 'https://ssl.smn.gob.ar/dpd/zipopendata.php?dato=pron5d'
            wget.download(urlpro)
            # descomprime un zip
            import shutil

            name1 = 'EstadoTiempo-' + fechaActual2 + '.zip'  # da el nombre al zip
            name2 = 'EstadoTiempo-' + fechaMañana2 + '.zip'  # da el nombre al zip
            namepro1='Pronostico5dias-' + fechaActual2 + '.zip'  # da el nombre al zip
            namepro2='Pronostico5dias-' + fechaMañana2 + '.zip'  # da el nombre al zip
            print("namepro2", namepro2)

            shutil.unpack_archive(name1)  # descomprime el zip
            os.remove(name1)  # borra el archivo zip descargado
            shutil.unpack_archive(namepro1)  # descomprime el zip
            os.remove(namepro1)  # borra el archivo zip descargado

            # lee datos del txt
            archivo = open("estado_tiempo" + fechaActual1 + ".txt")
            # print(archivo.read()) # lee el contenido del archivo

            # define el archivo como un array
            datos = []
            with open("estado_tiempo" + fechaActual1 + ".txt") as archivo:
                for line in archivo:
                    dato = [item.strip() for item in line.split(';')]
                    datos.append(dato)

            #numero_loc['text'] = "27"  # vacio para generar un espacio
            #print (numero_loc['text'])
            valor_localidad = numero_loc['text']
            valor_localidad = int(valor_localidad)
            valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico

            # *********************** inicio list box **********************************************
            datos1 = (datos[valor_localidad])
            print("primer datos1",datos1)
            # ***********************************************************************************
            cantidad_loc = len(datos)

            valor_nuevo = 0
            valor_lista = 0

            opciones = []
            for x in range(cantidad_loc):
                datos2 = datos[valor_lista]  # genera un nuevo dato con el valor de la cantidad de localidades
                # print(valor_nuevo,":" ,datos2[0]) # imprime la lista de localidades numeradas
                # label1=Label(text=(valor_nuevo,":" ,datos2[0]),borderwidth=2,justify=LEFT,font=20).pack()
                opciones.append(datos2[0])  # agrega los item a la listbox
                valor_lista += 1

                
                
                clima_x = datos1[3]
                print("clima_x", clima_x)
                if "lluv" in clima_x:
                    llovisna = PhotoImage(file="lluvia2.png")
                    Imagen2 = Label(ventanaclima, image=llovisna).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="lluvia.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "Lluv" in clima_x:
                    llovisna = PhotoImage(file="lluvia2.png")
                    Imagen2 = Label(ventanaclima, image=llovisna).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="lluvia.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "elec" in clima_x:
                    electrica2 = PhotoImage(file="electrica2.png")
                    Imagen2 = Label(ventanaclima, image=electrica2).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="electrica.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "Elec" in clima_x:
                    electrica2 = PhotoImage(file="electrica2.png")
                    Imagen2 = Label(ventanaclima, image=electrica2).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="electrica.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "Par" in clima_x:
                    algonublado = PhotoImage(file="algonublado.png")
                    Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="parcialmente.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "par" in clima_x:
                    algonublado = PhotoImage(file="algonublado.png")
                    Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="parcialmente.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                elif "sol" in clima_x:
                    sol = PhotoImage(file="sol.png")
                    Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="soleado.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "Sol" in clima_x:
                    sol = PhotoImage(file="sol.png")
                    Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="soleado.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "cub" in clima_x:
                    cubierto2 = PhotoImage(file="cubierto2.png")
                    Imagen2 = Label(ventanaclima, image=cubierto2).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="cubierto.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "Cub" in clima_x:
                    cubierto2 = PhotoImage(file="cubierto2.png")
                    Imagen2 = Label(ventanaclima, image=cubierto2).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="cubierto.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "nub" in clima_x:
                    algonublado = PhotoImage(file="algonublado.png")
                    Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="nublado.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "Nub" in clima_x:
                    algonublado = PhotoImage(file="algonublado.png")
                    Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="nublado.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "desp" in clima_x:
                    sol = PhotoImage(file="sol.png")
                    Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="fotonube2.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                elif "Desp" in clima_x:
                    sol = PhotoImage(file="sol.png")
                    Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
                    cielo = PhotoImage(file="fotonube2.png")
                    Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
                    
                # *********************** fin clima parte superior ********************************

                print(" ")
                print("Localidad:", datos1[0])
                print("Fecha:", datos1[1])
                print("hora de medicion", datos1[2])
                print("cielo", datos1[3])
                print("visibilidad", datos1[4])
                print("Temp.Maxima", datos1[5])
                print("Sensacion Termica", datos1[6])
                print("humedad", datos1[7], "%")
                print("viento", datos1[8], "kmh")
                print("presion Atmosferica", datos1[9])
                print("")


                fecha_texto_1['text'] = dia_hoy
                loc_texto_2['text'] = datos1[0]
                med_texto_5['text'] = datos1[2] + " Hs."
                max_texto_6['text'] = datos1[5] + "º"
                hum_texto_8['text'] = "Humedad: " + datos1[7] + "%"
                term_texto_9['text'] = "Sen.Termica: " + datos1[6]
                atm_texto_10['text'] = "P.Atm: " + datos1[9]
                cielo_texto_11['text'] = datos1[3]
                vis_texto_12['text'] = "Visibilidad: " + datos1[4]
                viento_texto_15['text'] = "Viento: " + datos1[8] + "km."
                data_mañana_19['text'] = dia_mañana
                data_pasado_20['text'] = dia_pasado
                data_pasado2_21['text'] = dia_pasado2



                if float(datos1[5]) < 5:
                    Imagmuchofrio = Label(ventanaclima, image=muchofrio).place(x=280, y=850, height=12, width=127)

                elif float(datos1[5]) >5 and float(datos1[5]) <= 13:
                    Imagfrio = Label(ventanaclima, image=frio).place(x=280, y=850, height=12, width=127)

                elif float(datos1[5]) >13 and float(datos1[5]) <= 21:
                    Imagfresco = Label(ventanaclima, image=fresco).place(x=280, y=850, height=12, width=127)

                elif float(datos1[5]) >21 and float(datos1[5]) <= 25:
                    Imagtemp = Label(ventanaclima, image=templado).place(x=280, y=850, height=12, width=127)

                elif float(datos1[5]) >25 and float(datos1[5]) <= 32:
                    Imagcalor = Label(ventanaclima, image=calor).place(x=280, y=850, height=12, width=127)

                elif float(datos1[5]) >32:
                    Imagmuchocalor = Label(ventanaclima, image=muchocalor).place(x=280, y=850, height=12, width=127)



                os.remove(archivo.name)  # borra el archivo txt descomprimido

                #////////////////////////////////////////////////////////////////////////// pronostico

                valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico

                with open("pronostico_5dias" + fechaActual1 + ".txt") as pronostico:
                    lines = pronostico.readlines()

                large_str = ''  # define variable de la linea agregada
                for line in lines:  # genera la lista
                    large_str += line.rstrip()  # agrega una linea al bucle

                valor = valor_pro  # variable de busque de localidad

                if (valor in lines) == True:
                    print("el valor es igual a ", valor)
                    vlinea = lines.index(valor)
                    print("el numero de linea es", vlinea)
                    x1 = vlinea + 10
                    x2 = vlinea + 18
                    x3 = vlinea + 26

                    locx = lines[vlinea]  # localidad
                    primeralinea = lines[x1]
                    segundalinea = lines[x2]
                    terceralinea = lines[x3]
                    print(locx)
                    print(primeralinea)
                    print(segundalinea)
                    print(terceralinea)

                    print("Fecha:", primeralinea[0:13])
                    mañana_texto_16['text'] = primeralinea[0:13]
                    print("Hora:", primeralinea[14:19])
                    hora_16['text'] =primeralinea[14:19]
                    print("Temperatura", primeralinea[27:31])
                    maxpro_25['text'] =primeralinea[27:31]
                    print("Dir.Viento:", primeralinea[38:41])
                    datoviento_25['text'] =primeralinea[38:41]
                    print("Velocidad del viento:", primeralinea[44:47], "Km/H")
                    veldato_25['text'] =primeralinea[44:47]
                    print("Precipitacion", primeralinea[54:60])
                    prec_1['text'] =primeralinea[54:60]
                    pre1 = primeralinea[54:60]
                    pre1 = float(pre1)



                    if pre1 <= 0.0:
                        mañanacielo['text'] ="Despejado"
                        solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=900, height=100, width=118)
                        print("Despejado")
                    elif pre1 > 0.0 and pre1 <= 0.3:
                        mañanacielo['text'] ="Soleado con nubes"
                        algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=900, height=100, width=118)
                        print("Soleado con nubes")
                    elif pre1 > 0.3 and pre1 <= 0.5:
                        mañanacielo['text'] ="Nublado"
                        nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=900, height=100, width=118)
                        print("Nublado")
                    elif pre1 > 0.5 and pre1 <= 1.5:
                        mañanacielo['text'] ="Lluvia muy débil"
                        lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=900, height=100, width=118)
                        print("Lluvia muy débil")
                    elif pre1 > 1.5 and pre1 <= 2:
                        mañanacielo['text'] ="Lluvia débil"
                        lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=900, height=100, width=118)
                        print("Lluvia débil")
                    elif pre1 > 2 and pre1 <= 6.5:
                        mañanacielo['text'] ="Lluvia ligera"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                        print("Lluvia ligera")
                    elif pre1 > 6.5 and pre1 <= 16:
                        mañanacielo['text'] ="Lluvia moderada"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                        print("Lluvia moderada")
                    elif pre1 > 16 and pre1 <= 40:
                        mañanacielo['text'] ="Lluvia fuerte"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                        print("Lluvia fuerte")
                    elif pre1 > 40 and pre1 <= 100:
                        mañanacielo['text'] ="Lluvia torrencial"
                        torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=900, height=100, width=118)
                        print("Lluvia torrencial")
                    elif pre1 > 100 and pre1 <= 250:
                        mañanacielo['text'] ="Torrencial y prob.granizo"
                        granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=900, height=100, width=118)
                        print("Torrencial y prob.granizo")
                    elif pre1 > 250:
                        mañanacielo['text'] ="Granizo de gran tamaño"
                        peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=900, height=100, width=118)
                        print("Granizo de gran tamaño")

                    print("")
                    print("Fecha:", segundalinea[0:13])
                    pasado_texto_17['text'] = segundalinea[0:13]
                    print("Hora:", segundalinea[14:19])
                    hora_17['text'] =segundalinea[14:19]
                    print("Temperatura", segundalinea[27:31])
                    maxpro_26['text'] = segundalinea[27:31]
                    print("Dir.Viento:", segundalinea[38:41])
                    datoviento_26['text']=segundalinea[38:41]
                    print("Velocidad del viento:", segundalinea[44:47], "Km/H")
                    veldato_26['text'] =segundalinea[44:47]
                    print("Precipitacion", segundalinea[54:60])
                    prec_2['text'] =segundalinea[54:60]
                    seg1 = segundalinea[54:60]
                    seg1 = float(seg1)
                    if seg1 <= 0.0:
                        pasadocielo1['text'] = "Despejado"
                        solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1050, height=100, width=118)
                        print("Despejado")
                    elif seg1 > 0.0 and seg1 <= 0.3:
                        pasadocielo1['text'] ="Soleado con nubes"
                        algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1050, height=100, width=118)
                        print("Soleado con nubes")
                    elif seg1 > 0.3 and seg1 <= 0.5:
                        pasadocielo1['text'] ="Nublado"
                        nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1050, height=100, width=118)
                        print("Nublado")
                    elif seg1 > 0.5 and seg1 <= 1.5:
                        pasadocielo1['text'] ="Lluvia muy débil"
                        lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1050, height=100, width=118)
                        print("Lluvia muy débil")
                    elif seg1 > 1.5 and seg1 <= 2:
                        pasadocielo1['text'] ="Lluvia débil"
                        lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1050, height=100, width=118)
                        print("Lluvia débil")
                    elif seg1 > 2 and seg1 <= 6.5:
                        pasadocielo1['text'] ="Lluvia ligera"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
                        print("Lluvia ligera")
                    elif seg1 > 6.5 and seg1 <= 16:
                        pasadocielo1['text'] ="Lluvia moderada"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
                        print("Lluvia moderada")
                    elif seg1 > 16 and seg1 <= 40:
                        pasadocielo1['text'] ="Lluvia fuerte"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
                        print("Lluvia fuerte")
                    elif seg1 > 40 and seg1 <= 100:
                        pasadocielo1['text'] ="Lluvia torrencial"
                        torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1050, height=100, width=118)
                        print("Lluvia torrencial")
                    elif seg1 > 100 and seg1 <= 250:
                        pasadocielo1['text'] ="Torrencial y prob.granizo"
                        granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1050, height=100, width=118)
                        print("Torrencial y prob.granizo")
                    elif seg1 > 250:
                        pasadocielo1['text'] ="Granizo de gran tamaño"
                        peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1050, height=100, width=118)
                        print("Granizo de gran tamaño")


                    print("")
                    print("Fecha:", terceralinea[0:13])
                    pasado2_texto_18['text'] = terceralinea[0:13]
                    print("Hora:", terceralinea[14:19])
                    hora_18['text'] =terceralinea[14:19]
                    print("Temperatura", terceralinea[27:31])
                    maxpro_27['text'] = terceralinea[27:31]
                    print("Dir.Viento:", terceralinea[38:41])
                    datoviento_27['text'] =terceralinea[38:41]
                    print("Velocidad del viento:", terceralinea[44:47], "Km/H")
                    veldato_27['text'] =terceralinea[44:47]
                    print("Precipitacion", terceralinea[54:60])
                    prec_3['text'] =terceralinea[54:60]
                    ter1 = terceralinea[54:60]
                    ter1 = float(ter1)
                    if ter1 <= 0.0:
                        pasadocielo2['text'] ="Despejado"
                        solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1200, height=100, width=118)
                        print("Despejado")
                    elif ter1 > 0.0 and ter1 <= 0.3:
                        pasadocielo2['text'] ="Soleado con nubes"
                        algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1200, height=100, width=118)
                        print("Soleado con nubes")
                    elif ter1 > 0.3 and ter1 <= 0.5:
                        pasadocielo2['text'] ="Nublado"
                        nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1200, height=100, width=118)
                        print("Nublado")
                    elif ter1 > 0.5 and ter1 <= 1.5:
                        pasadocielo2['text'] ="Lluvia muy débil"
                        lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1200, height=100, width=118)
                        print("Lluvia muy débil")
                    elif ter1 > 1.5 and ter1 <= 2:
                        pasadocielo2['text'] ="Lluvia débil"
                        lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1200, height=100, width=118)
                        print("Lluvia débil")
                    elif ter1 > 2 and ter1 <= 6.5:
                        pasadocielo2['text'] ="Lluvia ligera"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
                        print("Lluvia ligera")
                    elif ter1 > 6.5 and ter1 <= 16:
                        pasadocielo2['text'] ="Lluvia moderada"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
                        print("Lluvia moderada")
                    elif ter1 > 16 and ter1 <= 40:
                        pasadocielo2['text'] ="Lluvia fuerte"
                        lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
                        print("Lluvia fuerte")
                    elif ter1 > 40 and ter1 <= 100:
                        pasadocielo2['text'] ="Lluvia torrencial"
                        torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1200, height=100, width=118)
                        print("Lluvia torrencial")
                    elif ter1 > 100 and ter1 <= 250:
                        pasadocielo2['text'] ="Torrencial y prob.granizo"
                        granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1200, height=100, width=118)
                        print("Torrencial y prob.granizo")
                    elif ter1 > 250:
                        pasadocielo2['text'] ="Granizo de gran tamaño"
                        peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1200, height=100, width=118)
                        print("Granizo de gran tamaño")

                else:
                                    

                    mañana_texto_16['text'] = "......"
                    hora_16['text'] = "......"
                    maxpro_25['text'] = "......"
                    datoviento_25['text'] = "......"
                    veldato_25['text'] = "......"
                    prec_1['text'] = "......"

                    pasado_texto_17['text'] ="......"
                    hora_17['text'] ="......"
                    maxpro_26['text'] ="......"
                    datoviento_26['text'] ="......"
                    veldato_26['text'] ="......"
                    prec_2['text'] = "......"

                    pasado2_texto_18['text'] ="......"
                    hora_18['text'] ="......"
                    maxpro_27['text'] ="......"
                    datoviento_27['text'] ="......"
                    veldato_27['text'] ="......"
                    prec_3['text'] ="......"
                    
                    
                    
                    
                    print("no es igual a  ESTO", valor)
                
                os.remove("pronostico_5dias" + fechaActual1 + ".txt")
                #/////////////////////////////////////// fin pronostico //////////////////////////////////////////////
                while True:
                    if localtime().tm_min==int(8) :
                        print ("actualizado")
                    else    :
                         ventanaclima.mainloop()

            
          
        
        root.mainloop()
  #********************** FIN ACTUALIZACION ******************************************************************

#                                  texto visible hora
# formulario 1
texto_hora = Label(root, fg='white', bg='gray', font=('sans-serif', 60, 'bold'), width=10)
texto_hora.grid(column=0, row=0, ipadx=1, ipady=1)

texto_fecha12 = Label(root, fg='white', bg='gray', font=('Felix Titling', 30), width=20)
texto_fecha12.grid(column=0, row=1, ipadx=3, ipady=3)

horaubic = Label(root, fg='white', bg='gray',text="Argentina - Buenos Aires", font=('sans-serif', 17), width=20)
horaubic.grid(column=0, row=2, ipadx=5, ipady=5)
# *********************************************************************************************
tiempo()# llamada a el DEF de la actualizacion
# formulario 2

hoy = date.today()
dia_hoy = hoy.strftime('%A')
if dia_hoy == "Monday":
    dia_hoy = "Lunes"
elif dia_hoy == "Tuesday":
    dia_hoy = "Martes"
elif dia_hoy == "Wednesday":
    dia_hoy = "Miercoles"
elif dia_hoy == "Thursday":
    dia_hoy = "Jueves"
elif dia_hoy == "Friday":
    dia_hoy = "Viernes"
elif dia_hoy == "Saturday":
    dia_hoy = "Sabado"
elif dia_hoy == "Sunday":
    dia_hoy = "Domingo"

mañana = hoy + timedelta(days=1)
dia_mañana = mañana.strftime('%A')
if dia_mañana == "Monday":
    dia_mañana = "Lunes"
elif dia_mañana == "Tuesday":
    dia_mañana = "Martes"
elif dia_mañana == "Wednesday":
    dia_mañana = "Miercoles"
elif dia_mañana == "Thursday":
    dia_mañana = "Jueves"
elif dia_mañana == "Friday":
    dia_mañana = "Viernes"
elif dia_mañana == "Saturday":
    dia_mañana = "Sabado"
elif dia_mañana == "Sunday":
    dia_mañana = "Domingo"

pasado = hoy + timedelta(days=2)
dia_pasado = pasado.strftime('%A')
if dia_pasado == "Monday":
    dia_pasado = "Lunes"
elif dia_pasado == "Tuesday":
    dia_pasado = "Martes"
elif dia_pasado == "Wednesday":
    dia_pasado = "Miercoles"
elif dia_pasado == "Thursday":
    dia_pasado = "Jueves"
elif dia_pasado == "Friday":
    dia_pasado = "Viernes"
elif dia_pasado == "Saturday":
    dia_pasado = "Sabado"
elif dia_pasado == "Sunday":
    dia_pasado = "Domingo"

pasado2 = hoy + timedelta(days=3)
dia_pasado2 = pasado2.strftime('%A')
if dia_pasado2 == "Monday":
    dia_pasado2 = "Lunes"
elif dia_pasado2 == "Tuesday":
    dia_pasado2 = "Martes"
elif dia_pasado2 == "Wednesday":
    dia_pasado2 = "Miercoles"
elif dia_pasado2 == "Thursday":
    dia_pasado2 = "Jueves"
elif dia_pasado2 == "Friday":
    dia_pasado2 = "Viernes"
elif dia_pasado2 == "Saturday":
    dia_pasado2 = "Sabado"
elif dia_pasado2 == "Sunday":
    dia_pasado2 = "Domingo"

# ********************************************************************************************
numero_loc = Label(ventanaclima, fg='white',bg='black', font=('sans-serif', 30), width=5)
numero_loc.place(x=300, y=540)

texto_0 = Label(ventanaclima, fg='white',text='Hoy', bg='black', font=('sans-serif', 55), width=5)
texto_0.place(x=225, y=380)

fecha_texto_1 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 25), width=10)
fecha_texto_1.place(x=230, y=470)

loc_texto_2 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 25), width=20)
loc_texto_2.place(x=45, y=540)

texto_3 = Label(ventanaclima, fg='white', bg='black',text='H.Medicion: ', font=('sans-serif', 15), width=15,anchor='nw')
texto_3.place(x=10, y=690)

texto_4 = Label(ventanaclima, fg='white', bg='black',text='MAX:', font=('sans-serif', 30), width=5)
texto_4.place(x=10, y=605)

med_texto_5 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=8,anchor='nw')
med_texto_5.place(x=115, y=690)

max_texto_6 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 30), width=5)
max_texto_6.place(x=125, y=605)

texto_7 = Label(ventanaclima, fg='white', bg='black',text='Viento', font=('sans-serif', 30), width=6)
texto_7.place(x=200, y=730)

hum_texto_8 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=15,anchor='nw')
hum_texto_8.place(x=270, y=600)

term_texto_9 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=25,anchor='nw')
term_texto_9.place(x=170, y=810)

atm_texto_10 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=15,anchor='nw')
atm_texto_10.place(x=270, y=630)

cielo_texto_11 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=40,anchor='nw')
cielo_texto_11.place(x=10, y=660)

vis_texto_12 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=15,anchor='nw')
vis_texto_12.place(x=270, y=690)

viento_texto_15 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=20,anchor='nw')
viento_texto_15.place(x=190, y=780)

mañana_texto_16 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=15)
mañana_texto_16.place(x=10, y=1020)

mañanacielo = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 12), width=27)
mañanacielo.place(x=3, y=1000)

pasado_texto_17 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=15)
pasado_texto_17.place(x=10, y=1170)

pasadocielo1 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 12), width=27)
pasadocielo1.place(x=3, y=1150)

pasado2_texto_18 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 15), width=15)
pasado2_texto_18.place(x=5, y=1320)

pasadocielo2 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 12), width=27)
pasadocielo2.place(x=3, y=1300)


data_mañana_19 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 18), width=10)
data_mañana_19.place(x=290, y=920)

data_pasado_20 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 18), width=10)
data_pasado_20.place(x=290, y=1070)

data_pasado2_21 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 18), width=10)
data_pasado2_21.place(x=290, y=1220)

max1_22: Label = Label(ventanaclima, fg='white', text='Maxima:',bg='black', font=('sans-serif', 13), width=10)
max1_22.place(x=280, y=950)

max2_23 = Label(ventanaclima, fg='white', bg='black',text='Maxima:', font=('sans-serif', 13), width=10)
max2_23.place(x=280, y=1100)

max3_24 = Label(ventanaclima, fg='white', bg='black',text='Maxima:', font=('sans-serif', 13), width=10)
max3_24.place(x=280, y=1250)

maxpro_25: Label = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
maxpro_25.place(x=375, y=950)

maxpro_26 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
maxpro_26.place(x=375, y=1100)

maxpro_27 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
maxpro_27.place(x=375, y=1250)

hora_16 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 14), width=5)
hora_16.place(x=170, y=1020)

hora_17 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 14), width=5)
hora_17.place(x=170, y=1170)

hora_18 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 14), width=5)
hora_18.place(x=170, y=1320)

datoviento_25 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
datoviento_25.place(x=375, y=975)

datoviento_26 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
datoviento_26.place(x=375, y=1125)

datoviento_27 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
datoviento_27.place(x=375, y=1275)

viento1_22: Label = Label(ventanaclima, fg='white',text='Dir.Viento:', bg='black', font=('sans-serif', 13), width=10)
viento1_22.place(x=270, y=975)

viento2_23 = Label(ventanaclima, fg='white',text='Dir.Viento:', bg='black', font=('sans-serif', 13), width=10)
viento2_23.place(x=270, y=1125)

viento3_24 = Label(ventanaclima, fg='white',text='Dir.Viento:', bg='black', font=('sans-serif', 13), width=10)
viento3_24.place(x=270, y=1275)

velviento1_22 = Label(ventanaclima, fg='white',text='Vel.Viento:', bg='black', font=('sans-serif', 13), width=10)
velviento1_22.place(x=270, y=1000)

velviento2_23 = Label(ventanaclima, fg='white',text='Vel.Viento:', bg='black', font=('sans-serif', 13), width=10)
velviento2_23.place(x=270, y=1150)

velviento3_24 = Label(ventanaclima, fg='white',text='Vel.Viento:', bg='black', font=('sans-serif', 13), width=10)
velviento3_24.place(x=270, y=1300)

textoprec1 = Label(ventanaclima, fg='white',text='Precipitación:', bg='black', font=('sans-serif', 13), width=10)
textoprec1.place(x=260, y=1025)

textoprec2 = Label(ventanaclima, fg='white',text='Precipitación:', bg='black', font=('sans-serif', 13), width=10)
textoprec2.place(x=260, y=1175)

textoprec3 = Label(ventanaclima, fg='white',text='Precipitación:', bg='black', font=('sans-serif', 13), width=10)
textoprec3.place(x=260, y=1325)


veldato_25 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
veldato_25.place(x=375, y=1000)

veldato_26 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
veldato_26.place(x=375, y=1150)

veldato_27 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
veldato_27.place(x=375, y=1300)

prec_1 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
prec_1.place(x=375, y=1025)

prec_2 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
prec_2.place(x=375, y=1175)

prec_3 = Label(ventanaclima, fg='white', bg='black', font=('sans-serif', 13), width=5)
prec_3.place(x=375, y=1325)

#******************************* imagenes pronostico *******************************************

solpro = PhotoImage(file="solpro.png")
nubladopro = PhotoImage(file="nubladopro.png")
algocubiertopro=PhotoImage(file="algocubiertopro.png")
lluviaspro=PhotoImage(file="lluviaspro.png")
lluviaslevespro=PhotoImage(file="lluviaslevespro.png")
lluviasmuylevespro = PhotoImage(file="lluviasmuylevespro.png")
torrencialpro=PhotoImage(file="torrencialpro.png")
granizopro = PhotoImage(file="granizopro.png")
peligrogranizo = PhotoImage(file="peligrogranizo.png")

muchofrio = PhotoImage(file="muchofrio.png")
frio = PhotoImage(file="frio.png")
fresco = PhotoImage(file="fresco.png")
templado = PhotoImage(file="templado.png")
calor = PhotoImage(file="calor.png")
muchocalor = PhotoImage(file="muchocalor.png")


# **********************************************************************************************


viento = PhotoImage(file="viento2.png")
Imagen2 = Label(ventanaclima, image=viento).place(x=50, y=740, height=80, width=110)

# *********************************************************************************************



obtener_tiempo()

fechaActual = datetime.datetime.now()  # declara la fecha u hora actual
print("fechaActual ", fechaActual)

horaAct1 = datetime.datetime.strftime(fechaActual, '%H%M')  # da el formato para hora de actualizacion

a = 1
if (a == 1):  # if (horaAct1=="0800") or  (horaAct1=="0344"):
    fechaActual1 = datetime.datetime.strftime(fechaActual,'20%y%m%d')  # declara el formato para la apertura del archivo
    print("fechaActual1",fechaActual1)
    fechaActual2 = datetime.datetime.strftime(fechaActual,'%d%m20%y')  # declara el formato para name1 osea nombre del zip
    print("fecha actual2", fechaActual2)

    fechaMañana1 = datetime.datetime.strftime(mañana, '20%y%m%d')  # declara el formato para la apertura del archivo
    print("fechamanaña1",fechaMañana1)
    fechaMañana2 = datetime.datetime.strftime(mañana, '%d%m20%y')  # declara el formato para name1 osea nombre del zip

    url = 'https://ssl.smn.gob.ar/dpd/zipopendata.php?dato=tiepre'
    wget.download(url)
    urlpro = 'https://ssl.smn.gob.ar/dpd/zipopendata.php?dato=pron5d'
    wget.download(urlpro)
    # descomprime un zip
    import shutil

    name1 = 'EstadoTiempo-' + fechaActual2 + '.zip'  # da el nombre al zip
    name2 = 'EstadoTiempo-' + fechaMañana2 + '.zip'  # da el nombre al zip
    namepro1='Pronostico5dias-' + fechaActual2 + '.zip'  # da el nombre al zip
    namepro2='Pronostico5dias-' + fechaMañana2 + '.zip'  # da el nombre al zip
    print("namepro2", namepro2)
#**********************************************************************************************
#**********************************************************************************************
#**********************************************************************************************
# inicio codido en caso de error  **************************************************************


try:
    shutil.unpack_archive(name2)  # descomprime el zip
    os.remove(name2)  # borra el archivo zip descargado
    # lee datos del txt
    shutil.unpack_archive(namepro2)  # descomprime el zip
    os.remove(namepro2)  # borra el archivo zip descargado
    # lee datos del txt


    archivo = open("estado_tiempo" + fechaMañana1 + ".txt")
    archivo2 = open("pronostico_5dias" + fechaMañana1 + ".txt")

    datos = []
    with open("estado_tiempo" + fechaMañana1 + ".txt") as archivo:
        for line in archivo:
            dato = [item.strip() for item in line.split(';')]
            datos.append(dato)

    cantidad_loc = len(datos)

    numero_loc['text'] = "27"  # vacio para generar un espacio
    valor_localidad = numero_loc['text']
    valor_localidad = int(valor_localidad)

    opciones = []
    datos1 = (datos[valor_localidad])
    # *********************** inicio list box *************************************************************
    valor_nuevo = 0
    valor_lista = 0

    if float(datos1[5]) < 5:
        #muchofrio = PhotoImage(file="muchofrio.png")
        Imagmuchofrio = Label(ventanaclima, image=muchofrio).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) >5 and float(datos1[5]) <= 13:
        #frio = PhotoImage(file="frio.png")
        Imagfrio = Label(ventanaclima, image=frio).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) >13 and float(datos1[5]) <= 21:
        #fresco = PhotoImage(file="fresco.png")
        Imagfresco = Label(ventanaclima, image=fresco).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) >21 and float(datos1[5]) <= 25:
        #templado = PhotoImage(file="templado.png")
        Imagtemp = Label(ventanaclima, image=templado).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) >25 and float(datos1[5]) <= 32:
        #calor = PhotoImage(file="calor.png")
        Imagcalor = Label(ventanaclima, image=calor).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) >32:
        #muchocalor = PhotoImage(file="muchocalor.png")
        Imagmuchocalor = Label(ventanaclima, image=muchocalor).place(x=280, y=850, height=12, width=127)

    for x in range(cantidad_loc):
        datos2 = datos[valor_lista]
        opciones.append(datos2[0])  # agrega los item a la listbox

        valor_lista += 1

    class Window:
        def __init__(self, master):
            self.master = master
            self.frame = tk.Frame(self.master)
            self.frame.pack(padx=4, pady=530)  # cambia la unicacion
            var = tk.StringVar(root)
            self.values = [*opciones]  # contiene el array

            self.var = tk.StringVar(value=self.values[29])  # asigna el valor que se presenta en el listbox
            self.var.set(datos1[0])  # define el valor de localidad tomando datos de "datos1"
            self.menu = tk.OptionMenu(self.frame, self.var, *self.values, command=self.changecolor)
            self.menu.configure(font="sans-serif 25 bold")  # cambia la fuente
            self.menu.configure(fg='white')  # cambia el color de la letra
            self.menu.configure(background='black')
            self.menu.configure(highlightbackground='black')
            self.menu.pack(ipadx=90, ipady=4)  # cambia el borde

        def changecolor(self, value):



            print("*****************************************")
            x = value

            if x== "Azul":
                numero_loc['text'] = "0"
                valor_pro = ' AZUL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bahía Blanca":
                numero_loc['text'] = "1"
                valor_pro = ' BAHIA_BLANCA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Benito Juárez":
                numero_loc['text'] = "2"
                valor_pro = ' BENITO_JUAREZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bolívar":
                numero_loc['text'] = "3"
                valor_pro = ' BOLIVAR_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Campo de Mayo":
                numero_loc['text'] = "4"
                valor_pro = ' SAN_MIGUEL\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Coronel Pringles":
                numero_loc['text'] = "5"
                valor_pro = ' CORONEL_PRINGLES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Coronel Suarez":
                numero_loc['text'] = "6"
                valor_pro = ' CORONEL_SUAREZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Dolores":
                numero_loc['text'] = "7"
                valor_pro = ' DOLORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Palomar":
                numero_loc['text'] = "8"
                valor_pro = ' EL_PALOMAR_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ezeiza":
                numero_loc['text'] = "9"
                valor_pro = ' EZEIZA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Junín":
                numero_loc['text'] = "10"
                valor_pro = ' JUNIN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "La Plata":
                numero_loc['text'] = "11"
                valor_pro = ' LA_PLATA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Las Flores":
                numero_loc['text'] = "12"
                valor_pro = ' LAS_FLORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mar del Plata":
                numero_loc['text'] = "13"
                valor_pro = ' MAR_DEL_PLATA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mariano Moreno":
                numero_loc['text'] = "14"
                valor_pro = ' MARIANO_MORENO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Merlo":
                numero_loc['text'] = "15"
                valor_pro = ' MERLO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Morón":
                numero_loc['text'] = "16"
                valor_pro = ' MORON_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Nueve de Julio":
                numero_loc['text'] = "17"
                valor_pro = ' NUEVE_DE_JULIO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Olavarría":
                numero_loc['text'] = "18"
                valor_pro = ' OLAVARRIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pehuajó":
                numero_loc['text'] = "19"
                valor_pro = ' PEHUAJO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pigué":
                numero_loc['text'] = "20"
                valor_pro = ' PIGUE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Punta Indio B.A.":
                numero_loc['text'] = "21"
                valor_pro = ' PUNTA_INDIO_B.A\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Fernando":
                numero_loc['text'] = "22"
                valor_pro = ' SAN_FERNANDO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tandil":
                numero_loc['text'] = "23"
                valor_pro = ' TANDIL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tres Arroyos":
                numero_loc['text'] = "24"
                valor_pro = ' TRES_ARROYOS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa Gesell":
                numero_loc['text'] = "25"
                valor_pro = ' VILLA_GESELL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Aeroparque Buenos Aires":
                numero_loc['text'] = "26"
                valor_pro = ' AEROPARQUE\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Buenos Aires":
                numero_loc['text'] = "27"
                valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Catamarca":
                numero_loc['text'] = "28"
                valor_pro = ' CATAMARCA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tinogasta":
                numero_loc['text'] = "29"
                valor_pro = ' TINOGASTA\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pcia. Roque Saenz Peña":
                numero_loc['text'] = "30"
                valor_pro = ' PCIA._ROQUE_SAENZ_PEÑA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Resistencia":
                numero_loc['text'] = "31"
                valor_pro = ' RESISTENCIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Comodoro Rivadavia":
                numero_loc['text'] = "32"
                valor_pro = ' COMODORO_RIVADAVIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Esquel":
                numero_loc['text'] = "33"
                valor_pro = ' ESQUEL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Paso De Indios":
                numero_loc['text'] = "34"
                valor_pro = ' PASO_DE_INDIOS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Puerto Madryn":
                numero_loc['text'] = "35"
                valor_pro = ' PUERTO_MADRYN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Trelew":
                numero_loc['text'] = "36"
                valor_pro = ' TRELEW_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Córdoba":
                numero_loc['text'] = "37"
                valor_pro = ' CORDOBA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Córdoba Observatorio":
                numero_loc['text'] = "38"
                valor_pro = ' CORDOBA_OBSERVATORIO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Esc. Aviación Militar":
                numero_loc['text'] = "39"
                valor_pro = ' ESC.AVIACION_MILITAR_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Laboulaye":
                numero_loc['text'] = "40"
                valor_pro = ' LABOULAYE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Marcos Juárez":
                numero_loc['text'] = "41"
                valor_pro = ' MARCOS_JUAREZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pilar Obs.":
                numero_loc['text'] = "42"
                valor_pro = ' PILAR_OBS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Cuarto":
                numero_loc['text'] = "43"
                valor_pro = ' RIO_CUARTO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa Dolores":
                numero_loc['text'] = "44"
                valor_pro = ' VILLA_DOLORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa María Del Río Seco":
                numero_loc['text'] = "45"
                valor_pro = ' VILLA_MARIA_DEL_RIO_SECO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Corrientes":
                numero_loc['text'] = "46"
                valor_pro = ' CORRIENTES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ituzaingó":
                numero_loc['text'] = "47"
                valor_pro = ' ITUZAINGO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mercedes":
                numero_loc['text'] = "48"
                valor_pro = ' MERCEDES_AERO_(CTES)\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Monte Caseros":
                numero_loc['text'] = "49"
                valor_pro = ' MONTE_CASEROS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Paso De Los Libres":
                numero_loc['text'] = "50"
                valor_pro = ' PASO_DE_LOS_LIBRES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Concordia":
                numero_loc['text'] = "51"
                valor_pro = ' CONCORDIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Gualeguaychú":
                numero_loc['text'] = "52"
                valor_pro = ' GUALEGUAYCHU_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Paraná":
                numero_loc['text'] = "53"
                valor_pro = ' PARANA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Formosa":
                numero_loc['text'] = "54"
                valor_pro = ' FORMOSA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Las Lomitas":
                numero_loc['text'] = "55"
                valor_pro = ' LAS_LOMITAS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mount Pleasant Airport (Islas Malvinas)":
                numero_loc['text'] = "56"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "La Quiaca":
                numero_loc['text'] = "57"
                valor_pro = ' LA_QUIACA_OBS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Jujuy":
                numero_loc['text'] = "58"
                valor_pro = ' JUJUY_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Jujuy Universidad Nacional":
                numero_loc['text'] = "59"
                valor_pro = ' JUJUY_U_N\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "General Pico":
                numero_loc['text'] = "60"
                valor_pro = ' GENERAL_PICO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Victorica":
                numero_loc['text'] = "61"
                valor_pro = ' VICTORICA\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Rosa":
                numero_loc['text'] = "62"
                valor_pro = ' SANTA_ROSA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chamical":
                numero_loc['text'] = "63"
                valor_pro = ' CHAMICAL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chepes":
                numero_loc['text'] = "64"
                valor_pro = ' CHEPES\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chilecito":
                numero_loc['text'] = "65"
                valor_pro = ' CHILECITO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "La Rioja":
                numero_loc['text'] = "66"
                valor_pro = ' LA_RIOJA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Malargue":
                numero_loc['text'] = "67"
                valor_pro = ' MALARGUE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mendoza":
                numero_loc['text'] = "68"
                valor_pro = ' MENDOZA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mendoza Observatorio":
                numero_loc['text'] = "69"
                valor_pro = ' MENDOZA_OBSERVATORIO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Carlos (Mza)":
                numero_loc['text'] = "70"
                valor_pro = ' SAN_CARLOS_(MZA)\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Martín (Mza)":
                numero_loc['text'] = "71"
                valor_pro = ' SAN_MARTIN_(MZA)\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Rafael":
                numero_loc['text'] = "72"
                valor_pro = ' SAN_RAFAEL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Uspallata":
                numero_loc['text'] = "73"
                valor_pro = ' USPALLATA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bernardo De Irigoyen":
                numero_loc['text'] = "74"
                valor_pro = ' BERNARDO_DE_IRIGOYEN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Iguazú":
                numero_loc['text'] = "75"
                valor_pro = ' IGUAZU_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Oberá":
                numero_loc['text'] = "76"
                valor_pro = ' OBERA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Posadas":
                numero_loc['text'] = "77"
                valor_pro = ' POSADAS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chapelco":
                numero_loc['text'] = "78"
                valor_pro = ' CHAPELCO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Neuquén":
                numero_loc['text'] = "79"
                valor_pro = ' NEUQUEN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bariloche":
                numero_loc['text'] = "80"
                valor_pro = ' BARILOCHE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Cipolletti":
                numero_loc['text'] = "81"
                valor_pro = ' CIPOLLETTI\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Bolsón":
                numero_loc['text'] = "82"
                valor_pro = ' EL_BOLSON_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Maquinchao":
                numero_loc['text'] = "83"
                valor_pro = ' MAQUINCHAO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Colorado":
                numero_loc['text'] = "84"
                valor_pro = ' RIO_COLORADO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Antonio Oeste":
                numero_loc['text'] = "85"
                valor_pro = ' SAN_ANTONIO_OESTE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Viedma":
                numero_loc['text'] = "86"
                valor_pro = ' VIEDMA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Metán":
                numero_loc['text'] = "87"
                valor_pro = ' METAN\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Orán":
                numero_loc['text'] = "88"
                valor_pro = ' ORAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Rivadavia":
                numero_loc['text'] = "89"
                valor_pro = ' RIVADAVIA\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Salta":
                numero_loc['text'] = "90"
                valor_pro = ' SALTA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tartagal":
                numero_loc['text'] = "91"
                valor_pro = ' TARTAGAL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Jachal":
                numero_loc['text'] = "92"
                valor_pro = ' JACHAL\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Juan":
                numero_loc['text'] = "93"
                valor_pro = ' SAN_JUAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Luis":
                numero_loc['text'] = "94"
                valor_pro = ' SAN_LUIS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Rosa del Conlara":
                numero_loc['text'] = "95"
                valor_pro = ' SANTA_ROSA_DE_CONLARA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa Reynolds":
                numero_loc['text'] = "96"
                valor_pro = ' VILLA_REYNOLDS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Calafate":
                numero_loc['text'] = "97"
                valor_pro = ' EL_CALAFATE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Gobernador Gregores":
                numero_loc['text'] = "98"
                valor_pro = ' GOBERNADOR_GREGORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Perito Moreno":
                numero_loc['text'] = "99"
                valor_pro = ' PERITO_MORENO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Puerto Deseado":
                numero_loc['text'] = "100"
                valor_pro = ' PUERTO_DESEADO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Gallegos":
                numero_loc['text'] = "101"
                valor_pro = ' RIO_GALLEGOS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Julián":
                numero_loc['text'] = "102"
                valor_pro = ' SAN_JULIAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Cruz":
                numero_loc['text'] = "103"
                valor_pro = ' SANTA_CRUZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ceres":
                numero_loc['text'] = "104"
                valor_pro = ' CERES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Trébol":
                numero_loc['text'] = "105"
                valor_pro = ' EL_TREBOL\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Rafaela":
                numero_loc['text'] = "106"
                valor_pro = ' RAFAELA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Reconquista":
                numero_loc['text'] = "107"
                valor_pro = ' RECONQUISTA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Rosario":
                numero_loc['text'] = "108"
                valor_pro = ' ROSARIO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Fe":
                numero_loc['text'] = "109"
                valor_pro = ' SAUCE_VIEJO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Sunchales":
                numero_loc['text'] = "110"
                valor_pro = ' SUNCHALES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Venado Tuerto":
                numero_loc['text'] = "111"
                valor_pro = ' VENADO_TUERTO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Termas de Rio Hondo":
                numero_loc['text'] = "112"
                valor_pro = ' TERMAS_DE_RIO_HONDO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santiago del Estero":
                numero_loc['text'] = "113"
                valor_pro = ' SANTIAGO_DEL_ESTERO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Grande B.A.":
                numero_loc['text'] = "114"
                valor_pro = ' RIO_GRANDE_B.A.\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ushuaia":
                numero_loc['text'] = "115"
                valor_pro = ' USHUAIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tucumán":
                numero_loc['text'] = "116"
                valor_pro = ' TUCUMAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Belgrano II":
                numero_loc['text'] = "117"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Esperanza":
                numero_loc['text'] = "118"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Carlini":
                numero_loc['text'] = "119"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Marambio":
                numero_loc['text'] = "120"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Orcadas":
                numero_loc['text'] = "121"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base San Martín":
                numero_loc['text'] = "122"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
                                     # coloco la palabra error que no existe en la lista para que me lleve al else

                #numero_loc['text'] = "50"  # vacio para generar un espacio
            valor_localidad = numero_loc['text']
            valor_localidad = int(valor_localidad)
            #valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico

            datos1 = (datos[valor_localidad])
            print(datos1)


            fecha_texto_1['text'] = dia_hoy
            loc_texto_2['text'] = datos1[0]
            med_texto_5['text'] = datos1[2] + " Hs."
            max_texto_6['text'] = datos1[5] + "º"
            hum_texto_8['text'] = "Humedad: " + datos1[7] + "%"
            term_texto_9['text'] = "Sen.Termica: " + datos1[6]
            atm_texto_10['text'] = "P.Atm: " + datos1[9]
            cielo_texto_11['text'] = datos1[3]
            vis_texto_12['text'] = "Visibilidad: " + datos1[4]
            viento_texto_15['text'] = "Viento: " + datos1[8] + "km."
            data_mañana_19['text'] = dia_mañana
            data_pasado_20['text'] = dia_pasado
            data_pasado2_21['text'] = dia_pasado2

            #  pronostico listbox de 9 - 12  segundo codigo ////////////////////////////////////


            with open("pronostico_5dias" + fechaMañana1 + ".txt") as pronostico:
                lines = pronostico.readlines()

            large_str = ''  # define variable de la linea agregada
            for line in lines:  # genera la lista
                large_str += line.rstrip()  # agrega una linea al bucle

            valor = valor_pro  # variable de busque de localidad

            if (valor in lines) == True:
                print("el valor es igual a ", valor)
                vlinea = lines.index(valor)
                print("el numero de linea es", vlinea)
                x1 = vlinea + 10
                x2 = vlinea + 18
                x3 = vlinea + 26

                locx = lines[vlinea]  # localidad
                primeralinea = lines[x1]
                segundalinea = lines[x2]
                terceralinea = lines[x3]
                print(locx)
                print(primeralinea)
                print(segundalinea)
                print(terceralinea)

                print("Fecha:", primeralinea[0:13])
                mañana_texto_16['text'] = primeralinea[0:13]
                print("Hora:", primeralinea[14:19])
                hora_16['text'] = primeralinea[14:19]
                print("Temperatura", primeralinea[27:31])
                maxpro_25['text'] = primeralinea[27:31]
                print("Dir.Viento:", primeralinea[38:41])
                datoviento_25['text'] = primeralinea[38:41]
                print("Velocidad del viento:", primeralinea[44:47], "Km/H")
                veldato_25['text'] = primeralinea[44:47]
                print("Precipitacion", primeralinea[54:60])
                prec_1['text'] = primeralinea[54:60]
                pre1 = primeralinea[54:60]
                pre1 = float(pre1)

                #solpro = PhotoImage(file="solpro.png")
                #nubladopro = PhotoImage(file="nubladopro.png")
                #algocubiertopro = PhotoImage(file="algocubiertopro.png")
                #lluviaspro = PhotoImage(file="lluviaspro.png")
                #lluviaslevespro = PhotoImage(file="lluviaslevespro.png")
                #lluviasmuylevespro = PhotoImage(file="lluviasmuylevespro.png")
                #torrencialpro = PhotoImage(file="torrencialpro.png")
                #granizopro = PhotoImage(file="granizopro.png")
                #peligrogranizo = PhotoImage(file="peligrogranizo.png")

                if pre1 <= 0.0:
                    mañanacielo['text'] = "Despejado"
                    solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=900, height=100, width=118)
                    print("Despejado")
                elif pre1 > 0.0 and pre1 <= 0.3:
                    mañanacielo['text'] = "Soleado con nubes"
                    algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=900, height=100,
                                                                                             width=118)
                    print("Soleado con nubes")
                elif pre1 > 0.3 and pre1 <= 0.5:
                    mañanacielo['text'] = "Nublado"
                    nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=900, height=100, width=118)
                    print("Nublado")
                elif pre1 > 0.5 and pre1 <= 1.5:
                    mañanacielo['text'] = "Lluvia muy débil"
                    lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=900,
                                                                                                      height=100,
                                                                                                      width=118)
                    print("Lluvia muy débil")
                elif pre1 > 1.5 and pre1 <= 2:
                    mañanacielo['text'] = "Lluvia débil"
                    lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=900, height=100,
                                                                                                width=118)
                    print("Lluvia débil")
                elif pre1 > 2 and pre1 <= 6.5:
                    mañanacielo['text'] = "Lluvia ligera"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                    print("Lluvia ligera")
                elif pre1 > 6.5 and pre1 <= 16:
                    mañanacielo['text'] = "Lluvia moderada"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                    print("Lluvia moderada")
                elif pre1 > 16 and pre1 <= 40:
                    mañanacielo['text'] = "Lluvia fuerte"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                    print("Lluvia fuerte")
                elif pre1 > 40 and pre1 <= 100:
                    mañanacielo['text'] = "Lluvia torrencial"
                    torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=900, height=100,
                                                                                         width=118)
                    print("Lluvia torrencial")
                elif pre1 > 100 and pre1 <= 250:
                    mañanacielo['text'] = "Torrencial y prob.granizo"
                    granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=900, height=100, width=118)
                    print("Torrencial y prob.granizo")
                elif pre1 > 250:
                    mañanacielo['text'] = "Granizo de gran tamaño"
                    peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=900, height=100,
                                                                                           width=118)
                    print("Granizo de gran tamaño")

                print("")
                print("Fecha:", segundalinea[0:13])
                pasado_texto_17['text'] = segundalinea[0:13]
                print("Hora:", segundalinea[14:19])
                hora_17['text'] = segundalinea[14:19]
                print("Temperatura", segundalinea[27:31])
                maxpro_26['text'] = segundalinea[27:31]
                print("Dir.Viento:", segundalinea[38:41])
                datoviento_26['text'] = segundalinea[38:41]
                print("Velocidad del viento:", segundalinea[44:47], "Km/H")
                veldato_26['text'] = segundalinea[44:47]
                print("Precipitacion", segundalinea[54:60])
                prec_2['text'] = segundalinea[54:60]
                seg1 = segundalinea[54:60]
                seg1 = float(seg1)
                if seg1 <= 0.0:
                    pasadocielo1['text'] = "Despejado"
                    solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1050, height=100, width=118)
                    print("Despejado")
                elif seg1 > 0.0 and seg1 <= 0.3:
                    pasadocielo1['text'] = "Soleado con nubes"
                    algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1050, height=100,
                                                                                             width=118)
                    print("Soleado con nubes")
                elif seg1 > 0.3 and seg1 <= 0.5:
                    pasadocielo1['text'] = "Nublado"
                    nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1050, height=100, width=118)
                    print("Nublado")
                elif seg1 > 0.5 and seg1 <= 1.5:
                    pasadocielo1['text'] = "Lluvia muy débil"
                    lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1050,
                                                                                                      height=100,
                                                                                                      width=118)
                    print("Lluvia muy débil")
                elif seg1 > 1.5 and seg1 <= 2:
                    pasadocielo1['text'] = "Lluvia débil"
                    lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1050, height=100,
                                                                                                width=118)
                    print("Lluvia débil")
                elif seg1 > 2 and seg1 <= 6.5:
                    pasadocielo1['text'] = "Lluvia ligera"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100,
                                                                                      width=118)
                    print("Lluvia ligera")
                elif seg1 > 6.5 and seg1 <= 16:
                    pasadocielo1['text'] = "Lluvia moderada"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100,
                                                                                      width=118)
                    print("Lluvia moderada")
                elif seg1 > 16 and seg1 <= 40:
                    pasadocielo1['text'] = "Lluvia fuerte"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100,
                                                                                      width=118)
                    print("Lluvia fuerte")
                elif seg1 > 40 and seg1 <= 100:
                    pasadocielo1['text'] = "Lluvia torrencial"
                    torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1050, height=100,
                                                                                         width=118)
                    print("Lluvia torrencial")
                elif seg1 > 100 and seg1 <= 250:
                    pasadocielo1['text'] = "Torrencial y prob.granizo"
                    granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1050, height=100, width=118)
                    print("Torrencial y prob.granizo")
                elif seg1 > 250:
                    pasadocielo1['text'] = "Granizo de gran tamaño"
                    peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1050, height=100,
                                                                                           width=118)
                    print("Granizo de gran tamaño")

                print("")
                print("Fecha:", terceralinea[0:13])
                pasado2_texto_18['text'] = terceralinea[0:13]
                print("Hora:", terceralinea[14:19])
                hora_18['text'] = terceralinea[14:19]
                print("Temperatura", terceralinea[27:31])
                maxpro_27['text'] = terceralinea[27:31]
                print("Dir.Viento:", terceralinea[38:41])
                datoviento_27['text'] = terceralinea[38:41]
                print("Velocidad del viento:", terceralinea[44:47], "Km/H")
                veldato_27['text'] = terceralinea[44:47]
                print("Precipitacion", terceralinea[54:60])
                prec_3['text'] = terceralinea[54:60]
                ter1 = terceralinea[54:60]
                ter1 = float(ter1)
                if ter1 <= 0.0:
                    pasadocielo2['text'] = "Despejado"
                    solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1200, height=100, width=118)
                    print("Despejado")
                elif ter1 > 0.0 and ter1 <= 0.3:
                    pasadocielo2['text'] = "Soleado con nubes"
                    algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1200, height=100,
                                                                                             width=118)
                    print("Soleado con nubes")
                elif ter1 > 0.3 and ter1 <= 0.5:
                    pasadocielo2['text'] = "Nublado"
                    nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1200, height=100, width=118)
                    print("Nublado")
                elif ter1 > 0.5 and ter1 <= 1.5:
                    pasadocielo2['text'] = "Lluvia muy débil"
                    lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1200,
                                                                                                      height=100,
                                                                                                      width=118)
                    print("Lluvia muy débil")
                elif ter1 > 1.5 and ter1 <= 2:
                    pasadocielo2['text'] = "Lluvia débil"
                    lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1200, height=100,
                                                                                                width=118)
                    print("Lluvia débil")
                elif ter1 > 2 and ter1 <= 6.5:
                    pasadocielo2['text'] = "Lluvia ligera"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100,
                                                                                      width=118)
                    print("Lluvia ligera")
                elif ter1 > 6.5 and ter1 <= 16:
                    pasadocielo2['text'] = "Lluvia moderada"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100,
                                                                                      width=118)
                    print("Lluvia moderada")
                elif ter1 > 16 and ter1 <= 40:
                    pasadocielo2['text'] = "Lluvia fuerte"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100,
                                                                                      width=118)
                    print("Lluvia fuerte")
                elif ter1 > 40 and ter1 <= 100:
                    pasadocielo2['text'] = "Lluvia torrencial"
                    torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1200, height=100,
                                                                                         width=118)
                    print("Lluvia torrencial")
                elif ter1 > 100 and ter1 <= 250:
                    pasadocielo2['text'] = "Torrencial y prob.granizo"
                    granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1200, height=100, width=118)
                    print("Torrencial y prob.granizo")
                elif ter1 > 250:
                    pasadocielo2['text'] = "Granizo de gran tamaño"
                    peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1200, height=100,
                                                                                           width=118)
                    print("Granizo de gran tamaño")



            else:

                mañana_texto_16['text'] = "......"
                hora_16['text'] = "......"
                maxpro_25['text'] = "......"
                datoviento_25['text'] = "......"
                veldato_25['text'] = "......"
                prec_1['text'] = "......"

                pasado_texto_17['text'] ="......"
                hora_17['text'] ="......"
                maxpro_26['text'] ="......"
                datoviento_26['text'] ="......"
                veldato_26['text'] ="......"
                prec_2['text'] = "......"

                pasado2_texto_18['text'] ="......"
                hora_18['text'] ="......"
                maxpro_27['text'] ="......"
                datoviento_27['text'] ="......"
                veldato_27['text'] ="......"
                prec_3['text'] ="......"

                print("no es igual a ESTO 2 ", valor)
            # /////////////////////////////////////// fin pronostico //////////////////////////////////////////////


    window = Window(ventanaclima)
    # ******************************** final listbox *****************************************

   
    if "lluv" in cielo_texto_11['text'] :
        llovisna = PhotoImage(file="lluvia2.png")
        Imagen2 = Label(ventanaclima, image=llovisna).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="lluvia.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Lluv" in cielo_texto_11['text'] :
        llovisna = PhotoImage(file="lluvia2.png")
        Imagen2 = Label(ventanaclima, image=llovisna).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="lluvia.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "elec" in cielo_texto_11['text'] :
        electrica2 = PhotoImage(file="electrica2.png")
        Imagen2 = Label(ventanaclima, image=electrica2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="electrica.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Elec" in cielo_texto_11['text'] :
        electrica2 = PhotoImage(file="electrica2.png")
        Imagen2 = Label(ventanaclima, image=electrica2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="electrica.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Par" in cielo_texto_11['text'] :
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="parcialmente.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "par" in cielo_texto_11['text'] :
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="parcialmente.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "sol" in cielo_texto_11['text'] :
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="soleado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Sol" in cielo_texto_11['text'] :
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="soleado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
       
    elif "cub" in cielo_texto_11['text'] :
        cubierto2 = PhotoImage(file="cubierto2.png")
        Imagen2 = Label(ventanaclima, image=cubierto2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="cubierto.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "Cub" in cielo_texto_11['text'] :
        
        cubierto2 = PhotoImage(file="cubierto2.png")
        Imagen2 = Label(ventanaclima, image=cubierto2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="cubierto.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "nub" in cielo_texto_11['text'] :
        
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="nublado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Nub" in cielo_texto_11['text'] :
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="nublado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "desp" in cielo_texto_11['text'] :
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="fotonube2.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
       
    elif "Desp" in cielo_texto_11['text'] :
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="fotonube2.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    
    # *********************** fin clima parte superior ********************************
    
   
    print(" ")
    print("Localidad:", datos1[0])
    print("Fecha:", datos1[1])
    print("hora de medicion", datos1[2])
    print("cielo", datos1[3])
    print("visibilidad", datos1[4])
    print("Temp.Maxima", datos1[5])
    print("Sensacion Termica", datos1[6])
    print("humedad", datos1[7], "%")
    print("viento", datos1[8], "kmh")
    print("presion Atmosferica", datos1[9])
    print("")


    fecha_texto_1['text'] = dia_hoy
    loc_texto_2['text'] = datos1[0]
    med_texto_5['text'] = datos1[2] + " Hs."
    max_texto_6['text'] = datos1[5] + "º"
    hum_texto_8['text'] = "Humedad: " + datos1[7] + "%"
    term_texto_9['text'] = "Sen.Termica: " + datos1[6]
    atm_texto_10['text'] = "P.Atm: " + datos1[9]
    cielo_texto_11['text'] = datos1[3]
    vis_texto_12['text'] = "Visibilidad: " + datos1[4]
    viento_texto_15['text'] = "Viento: " + datos1[8] + "km."
    data_mañana_19['text'] = dia_mañana
    data_pasado_20['text'] = dia_pasado
    data_pasado2_21['text'] = dia_pasado2


    os.remove(archivo.name)  # borra el archivo txt descomprimido



    # *************************** pronostico entre 9-12 **************************************

    valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico

    with open("pronostico_5dias" + fechaMañana1 + ".txt") as pronostico:
        lines = pronostico.readlines()

    large_str = ''  # define variable de la linea agregada
    for line in lines:  # genera la lista
        large_str += line.rstrip()  # agrega una linea al bucle

    valor = valor_pro  # variable de busque de localidad

    if (valor in lines) == True:
        print("el valor es igual a ", valor)
        vlinea = lines.index(valor)
        print("el numero de linea es", vlinea)
        x1 = vlinea + 10
        x2 = vlinea + 18
        x3 = vlinea + 26

        locx = lines[vlinea]  # localidad
        primeralinea = lines[x1]
        segundalinea = lines[x2]
        terceralinea = lines[x3]
        print(locx)
        print(primeralinea)
        print(segundalinea)
        print(terceralinea)

        print("Fecha:", primeralinea[0:13])
        mañana_texto_16['text'] = primeralinea[0:13]
        print("Hora:", primeralinea[14:19])
        hora_16['text'] = primeralinea[14:19]
        print("Temperatura", primeralinea[27:31])
        maxpro_25['text'] = primeralinea[27:31]
        print("Dir.Viento:", primeralinea[38:41])
        datoviento_25['text'] = primeralinea[38:41]
        print("Velocidad del viento:", primeralinea[44:47], "Km/H")
        veldato_25['text'] = primeralinea[44:47]
        print("Precipitacion", primeralinea[54:60])
        prec_1['text'] = primeralinea[54:60]
        pre1 = primeralinea[54:60]
        pre1 = float(pre1)

        if pre1 <= 0.0:
            mañanacielo['text'] = "Despejado"
            solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=900, height=100, width=118)
            print("Despejado")
        elif pre1 > 0.0 and pre1 <= 0.3:
            mañanacielo['text'] = "Soleado con nubes"
            algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=900, height=100, width=118)
            print("Soleado con nubes")
        elif pre1 > 0.3 and pre1 <= 0.5:
            mañanacielo['text'] = "Nublado"
            nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=900, height=100, width=118)
            print("Nublado")
        elif pre1 > 0.5 and pre1 <= 1.5:
            mañanacielo['text'] = "Lluvia muy débil"
            lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=900, height=100,
                                                                                              width=118)
            print("Lluvia muy débil")
        elif pre1 > 1.5 and pre1 <= 2:
            mañanacielo['text'] = "Lluvia débil"
            lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=900, height=100,
                                                                                        width=118)
            print("Lluvia débil")
        elif pre1 > 2 and pre1 <= 6.5:
            mañanacielo['text'] = "Lluvia ligera"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
            print("Lluvia ligera")
        elif pre1 > 6.5 and pre1 <= 16:
            mañanacielo['text'] = "Lluvia moderada"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
            print("Lluvia moderada")
        elif pre1 > 16 and pre1 <= 40:
            mañanacielo['text'] = "Lluvia fuerte"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
            print("Lluvia fuerte")
        elif pre1 > 40 and pre1 <= 100:
            mañanacielo['text'] = "Lluvia torrencial"
            torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=900, height=100, width=118)
            print("Lluvia torrencial")
        elif pre1 > 100 and pre1 <= 250:
            mañanacielo['text'] = "Torrencial y prob.granizo"
            granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=900, height=100, width=118)
            print("Torrencial y prob.granizo")
        elif pre1 > 250:
            mañanacielo['text'] = "Granizo de gran tamaño"
            peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=900, height=100, width=118)
            print("Granizo de gran tamaño")

        print("")
        print("Fecha:", segundalinea[0:13])
        pasado_texto_17['text'] = segundalinea[0:13]
        print("Hora:", segundalinea[14:19])
        hora_17['text'] = segundalinea[14:19]
        print("Temperatura", segundalinea[27:31])
        maxpro_26['text'] = segundalinea[27:31]
        print("Dir.Viento:", segundalinea[38:41])
        datoviento_26['text'] = segundalinea[38:41]
        print("Velocidad del viento:", segundalinea[44:47], "Km/H")
        veldato_26['text'] = segundalinea[44:47]
        print("Precipitacion", segundalinea[54:60])
        prec_2['text'] = segundalinea[54:60]
        seg1 = segundalinea[54:60]
        seg1 = float(seg1)
        if seg1 <= 0.0:
            pasadocielo1['text'] = "Despejado"
            solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1050, height=100, width=118)
            print("Despejado")
        elif seg1 > 0.0 and seg1 <= 0.3:
            pasadocielo1['text'] = "Soleado con nubes"
            algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1050, height=100,
                                                                                     width=118)
            print("Soleado con nubes")
        elif seg1 > 0.3 and seg1 <= 0.5:
            pasadocielo1['text'] = "Nublado"
            nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1050, height=100, width=118)
            print("Nublado")
        elif seg1 > 0.5 and seg1 <= 1.5:
            pasadocielo1['text'] = "Lluvia muy débil"
            lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1050, height=100,
                                                                                              width=118)
            print("Lluvia muy débil")
        elif seg1 > 1.5 and seg1 <= 2:
            pasadocielo1['text'] = "Lluvia débil"
            lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1050, height=100,
                                                                                        width=118)
            print("Lluvia débil")
        elif seg1 > 2 and seg1 <= 6.5:
            pasadocielo1['text'] = "Lluvia ligera"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia ligera")
        elif seg1 > 6.5 and seg1 <= 16:
            pasadocielo1['text'] = "Lluvia moderada"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia moderada")
        elif seg1 > 16 and seg1 <= 40:
            pasadocielo1['text'] = "Lluvia fuerte"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia fuerte")
        elif seg1 > 40 and seg1 <= 100:
            pasadocielo1['text'] = "Lluvia torrencial"
            torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia torrencial")
        elif seg1 > 100 and seg1 <= 250:
            pasadocielo1['text'] = "Torrencial y prob.granizo"
            granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1050, height=100, width=118)
            print("Torrencial y prob.granizo")
        elif seg1 > 250:
            pasadocielo1['text'] = "Granizo de gran tamaño"
            peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1050, height=100, width=118)
            print("Granizo de gran tamaño")

        print("")
        print("Fecha:", terceralinea[0:13])
        pasado2_texto_18['text'] = terceralinea[0:13]
        print("Hora:", terceralinea[14:19])
        hora_18['text'] = terceralinea[14:19]
        print("Temperatura", terceralinea[27:31])
        maxpro_27['text'] = terceralinea[27:31]
        print("Dir.Viento:", terceralinea[38:41])
        datoviento_27['text'] = terceralinea[38:41]
        print("Velocidad del viento:", terceralinea[44:47], "Km/H")
        veldato_27['text'] = terceralinea[44:47]
        print("Precipitacion", terceralinea[54:60])
        prec_3['text'] = terceralinea[54:60]
        ter1 = terceralinea[54:60]
        ter1 = float(ter1)
        if ter1 <= 0.0:
            pasadocielo2['text'] = "Despejado"
            solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1200, height=100, width=118)
            print("Despejado")
        elif ter1 > 0.0 and ter1 <= 0.3:
            pasadocielo2['text'] = "Soleado con nubes"
            algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1200, height=100,
                                                                                     width=118)
            print("Soleado con nubes")
        elif ter1 > 0.3 and ter1 <= 0.5:
            pasadocielo2['text'] = "Nublado"
            nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1200, height=100, width=118)
            print("Nublado")
        elif ter1 > 0.5 and ter1 <= 1.5:
            pasadocielo2['text'] = "Lluvia muy débil"
            lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1200, height=100,
                                                                                              width=118)
            print("Lluvia muy débil")
        elif ter1 > 1.5 and ter1 <= 2:
            pasadocielo2['text'] = "Lluvia débil"
            lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1200, height=100,
                                                                                        width=118)
            print("Lluvia débil")
        elif ter1 > 2 and ter1 <= 6.5:
            pasadocielo2['text'] = "Lluvia ligera"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia ligera")
        elif ter1 > 6.5 and ter1 <= 16:
            pasadocielo2['text'] = "Lluvia moderada"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia moderada")
        elif ter1 > 16 and ter1 <= 40:
            pasadocielo2['text'] = "Lluvia fuerte"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia fuerte")
        elif ter1 > 40 and ter1 <= 100:
            pasadocielo2['text'] = "Lluvia torrencial"
            torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia torrencial")
        elif ter1 > 100 and ter1 <= 250:
            pasadocielo2['text'] = "Torrencial y prob.granizo"
            granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1200, height=100, width=118)
            print("Torrencial y prob.granizo")
        elif ter1 > 250:
            pasadocielo2['text'] = "Granizo de gran tamaño"
            peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1200, height=100, width=118)
            print("Granizo de gran tamaño")

    else:

            mañana_texto_16['text'] = "......"
            hora_16['text'] = "......"
            maxpro_25['text'] = "......"
            datoviento_25['text'] = "......"
            veldato_25['text'] = "......"
            prec_1['text'] = "......"

            pasado_texto_17['text'] ="......"
            hora_17['text'] ="......"
            maxpro_26['text'] ="......"
            datoviento_26['text'] ="......"
            veldato_26['text'] ="......"
            prec_2['text'] = "......"

            pasado2_texto_18['text'] ="......"
            hora_18['text'] ="......"
            maxpro_27['text'] ="......"
            datoviento_27['text'] ="......"
            veldato_27['text'] ="......"
            prec_3['text'] ="......"
                    
            os.remove("pronostico_5dias" + fechaMañana1 + ".txt")
            print("no es igual a ESTO3 ", valor)

#******************************************* fin pronostico de 9-12 ************************************
#*******************************************************************************************************
#*******************************************************************************************************
#*******************************************************************************************************
# ******************* *********************************************************************************
except:

                #*******************CODIGO DE INICIAL *************************************************

    shutil.unpack_archive(name1)  # descomprime el zip
    os.remove(name1)  # borra el archivo zip descargado
    shutil.unpack_archive(namepro1)  # descomprime el zip
    os.remove(namepro1)  # borra el archivo zip descargado

    # lee datos del txt
    archivo = open("estado_tiempo" + fechaActual1 + ".txt")
    # print(archivo.read()) # lee el contenido del archivo

    # define el archivo como un array
    datos = []
    with open("estado_tiempo" + fechaActual1 + ".txt") as archivo:
        for line in archivo:
            dato = [item.strip() for item in line.split(';')]
            datos.append(dato)

    numero_loc['text'] = "27"  # vacio para generar un espacio
    print ("numero que quiero",numero_loc['text'])   #ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg
    valor_localidad = numero_loc['text']
    valor_localidad = int(valor_localidad)
    valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico

    # *********************** inicio list box **********************************************
    datos1 = (datos[valor_localidad])
    print("primer datos1",datos1)
    # ***********************************************************************************


    
    cantidad_loc = len(datos)

    valor_nuevo = 0
    valor_lista = 0

    opciones = []
    for x in range(cantidad_loc):
        datos2 = datos[valor_lista]  # genera un nuevo dato con el valor de la cantidad de localidades
        # print(valor_nuevo,":" ,datos2[0]) # imprime la lista de localidades numeradas
        # label1=Label(text=(valor_nuevo,":" ,datos2[0]),borderwidth=2,justify=LEFT,font=20).pack()
        opciones.append(datos2[0])  # agrega los item a la listbox
        valor_lista += 1


    class Window:

        def __init__(self, master):
            self.master = master
            self.frame = tk.Frame(self.master)
            self.frame.pack(padx=4, pady=530)  # cambia la ubicacion
            var = tk.StringVar(root)
            self.values = [*opciones]  # contiene el array

            self.var = tk.StringVar(value=self.values[0])  # asigna el valor que se presenta en el listbox
            self.var.set(datos1[0])  # define el valor de localidad tomando datos de "datos1"
            self.menu = tk.OptionMenu(self.frame, self.var, *self.values, command=self.changecolor)
            self.menu.configure(font="sans-serif 25 bold")  # cambia la fuente
            self.menu.configure(fg='white')  # cambia el color de la letra
            self.menu.configure(background='black')
            self.menu.configure(highlightbackground='black')
            self.menu.pack(ipadx=90, ipady=4)  # cambia el borde

        def changecolor(self, value):




            print("*****************************************")
            x = value
            print("valor x",x)


            if x== "Azul":
                numero_loc['text'] = "0"
                valor_pro = ' AZUL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bahía Blanca":
                numero_loc['text'] = "1"
                valor_pro = ' BAHIA_BLANCA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Benito Juárez":
                numero_loc['text'] = "2"
                valor_pro = ' BENITO_JUAREZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bolívar":
                numero_loc['text'] = "3"
                valor_pro = ' BOLIVAR_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Campo de Mayo":
                numero_loc['text'] = "4"
                valor_pro = ' SAN_MIGUEL\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Coronel Pringles":
                numero_loc['text'] = "5"
                valor_pro = ' CORONEL_PRINGLES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Coronel Suarez":
                numero_loc['text'] = "6"
                valor_pro = ' CORONEL_SUAREZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Dolores":
                numero_loc['text'] = "7"
                valor_pro = ' DOLORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Palomar":
                numero_loc['text'] = "8"
                valor_pro = ' EL_PALOMAR_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ezeiza":
                numero_loc['text'] = "9"
                valor_pro = ' EZEIZA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Junín":
                numero_loc['text'] = "10"
                valor_pro = ' JUNIN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "La Plata":
                numero_loc['text'] = "11"
                valor_pro = ' LA_PLATA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Las Flores":
                numero_loc['text'] = "12"
                valor_pro = ' LAS_FLORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mar del Plata":
                numero_loc['text'] = "13"
                valor_pro = ' MAR_DEL_PLATA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mariano Moreno":
                numero_loc['text'] = "14"
                valor_pro = ' MARIANO_MORENO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Merlo":
                numero_loc['text'] = "15"
                valor_pro = ' MERLO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Morón":
                numero_loc['text'] = "16"
                valor_pro = ' MORON_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Nueve de Julio":
                numero_loc['text'] = "17"
                valor_pro = ' NUEVE_DE_JULIO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Olavarría":
                numero_loc['text'] = "18"
                valor_pro = ' OLAVARRIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pehuajó":
                numero_loc['text'] = "19"
                valor_pro = ' PEHUAJO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pigué":
                numero_loc['text'] = "20"
                valor_pro = ' PIGUE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Punta Indio B.A.":
                numero_loc['text'] = "21"
                valor_pro = ' PUNTA_INDIO_B.A\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Fernando":
                numero_loc['text'] = "22"
                valor_pro = ' SAN_FERNANDO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tandil":
                numero_loc['text'] = "23"
                valor_pro = ' TANDIL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tres Arroyos":
                numero_loc['text'] = "24"
                valor_pro = ' TRES_ARROYOS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa Gesell":
                numero_loc['text'] = "25"
                valor_pro = ' VILLA_GESELL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Aeroparque Buenos Aires":
                numero_loc['text'] = "26"
                valor_pro = ' AEROPARQUE\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Buenos Aires":
                numero_loc['text'] = "27"
                valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Catamarca":
                numero_loc['text'] = "28"
                valor_pro = ' CATAMARCA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tinogasta":
                numero_loc['text'] = "29"
                valor_pro = ' TINOGASTA\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pcia. Roque Saenz Peña":
                numero_loc['text'] = "30"
                valor_pro = ' PCIA._ROQUE_SAENZ_PEÑA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Resistencia":
                numero_loc['text'] = "31"
                valor_pro = ' RESISTENCIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Comodoro Rivadavia":
                numero_loc['text'] = "32"
                valor_pro = ' COMODORO_RIVADAVIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Esquel":
                numero_loc['text'] = "33"
                valor_pro = ' ESQUEL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Paso De Indios":
                numero_loc['text'] = "34"
                valor_pro = ' PASO_DE_INDIOS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Puerto Madryn":
                numero_loc['text'] = "35"
                valor_pro = ' PUERTO_MADRYN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Trelew":
                numero_loc['text'] = "36"
                valor_pro = ' TRELEW_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Córdoba":
                numero_loc['text'] = "37"
                valor_pro = ' CORDOBA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Córdoba Observatorio":
                numero_loc['text'] = "38"
                valor_pro = ' CORDOBA_OBSERVATORIO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Esc. Aviación Militar":
                numero_loc['text'] = "39"
                valor_pro = ' ESC.AVIACION_MILITAR_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Laboulaye":
                numero_loc['text'] = "40"
                valor_pro = ' LABOULAYE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Marcos Juárez":
                numero_loc['text'] = "41"
                valor_pro = ' MARCOS_JUAREZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Pilar Obs.":
                numero_loc['text'] = "42"
                valor_pro = ' PILAR_OBS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Cuarto":
                numero_loc['text'] = "43"
                valor_pro = ' RIO_CUARTO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa Dolores":
                numero_loc['text'] = "44"
                valor_pro = ' VILLA_DOLORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa María Del Río Seco":
                numero_loc['text'] = "45"
                valor_pro = ' VILLA_MARIA_DEL_RIO_SECO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Corrientes":
                numero_loc['text'] = "46"
                valor_pro = ' CORRIENTES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ituzaingó":
                numero_loc['text'] = "47"
                valor_pro = ' ITUZAINGO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mercedes":
                numero_loc['text'] = "48"
                valor_pro = ' MERCEDES_AERO_(CTES)\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Monte Caseros":
                numero_loc['text'] = "49"
                valor_pro = ' MONTE_CASEROS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Paso De Los Libres":
                numero_loc['text'] = "50"
                valor_pro = ' PASO_DE_LOS_LIBRES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Concordia":
                numero_loc['text'] = "51"
                valor_pro = ' CONCORDIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Gualeguaychú":
                numero_loc['text'] = "52"
                valor_pro = ' GUALEGUAYCHU_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Paraná":
                numero_loc['text'] = "53"
                valor_pro = ' PARANA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Formosa":
                numero_loc['text'] = "54"
                valor_pro = ' FORMOSA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Las Lomitas":
                numero_loc['text'] = "55"
                valor_pro = ' LAS_LOMITAS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mount Pleasant Airport (Islas Malvinas)":
                numero_loc['text'] = "56"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "La Quiaca":
                numero_loc['text'] = "57"
                valor_pro = ' LA_QUIACA_OBS\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Jujuy":
                numero_loc['text'] = "58"
                valor_pro = ' JUJUY_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Jujuy Universidad Nacional":
                numero_loc['text'] = "59"
                valor_pro = ' JUJUY_U_N\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "General Pico":
                numero_loc['text'] = "60"
                valor_pro = ' GENERAL_PICO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Victorica":
                numero_loc['text'] = "61"
                valor_pro = ' VICTORICA\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Rosa":
                numero_loc['text'] = "62"
                valor_pro = ' SANTA_ROSA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chamical":
                numero_loc['text'] = "63"
                valor_pro = ' CHAMICAL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chepes":
                numero_loc['text'] = "64"
                valor_pro = ' CHEPES\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chilecito":
                numero_loc['text'] = "65"
                valor_pro = ' CHILECITO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "La Rioja":
                numero_loc['text'] = "66"
                valor_pro = ' LA_RIOJA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Malargue":
                numero_loc['text'] = "67"
                valor_pro = ' MALARGUE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mendoza":
                numero_loc['text'] = "68"
                valor_pro = ' MENDOZA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Mendoza Observatorio":
                numero_loc['text'] = "69"
                valor_pro = ' MENDOZA_OBSERVATORIO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Carlos (Mza)":
                numero_loc['text'] = "70"
                valor_pro = ' SAN_CARLOS_(MZA)\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Martín (Mza)":
                numero_loc['text'] = "71"
                valor_pro = ' SAN_MARTIN_(MZA)\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Rafael":
                numero_loc['text'] = "72"
                valor_pro = ' SAN_RAFAEL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Uspallata":
                numero_loc['text'] = "73"
                valor_pro = ' USPALLATA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bernardo De Irigoyen":
                numero_loc['text'] = "74"
                valor_pro = ' BERNARDO_DE_IRIGOYEN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Iguazú":
                numero_loc['text'] = "75"
                valor_pro = ' IGUAZU_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Oberá":
                numero_loc['text'] = "76"
                valor_pro = ' OBERA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Posadas":
                numero_loc['text'] = "77"
                valor_pro = ' POSADAS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Chapelco":
                numero_loc['text'] = "78"
                valor_pro = ' CHAPELCO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Neuquén":
                numero_loc['text'] = "79"
                valor_pro = ' NEUQUEN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Bariloche":
                numero_loc['text'] = "80"
                valor_pro = ' BARILOCHE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Cipolletti":
                numero_loc['text'] = "81"
                valor_pro = ' CIPOLLETTI\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Bolsón":
                numero_loc['text'] = "82"
                valor_pro = ' EL_BOLSON_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Maquinchao":
                numero_loc['text'] = "83"
                valor_pro = ' MAQUINCHAO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Colorado":
                numero_loc['text'] = "84"
                valor_pro = ' RIO_COLORADO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Antonio Oeste":
                numero_loc['text'] = "85"
                valor_pro = ' SAN_ANTONIO_OESTE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Viedma":
                numero_loc['text'] = "86"
                valor_pro = ' VIEDMA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Metán":
                numero_loc['text'] = "87"
                valor_pro = ' METAN\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Orán":
                numero_loc['text'] = "88"
                valor_pro = ' ORAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Rivadavia":
                numero_loc['text'] = "89"
                valor_pro = ' RIVADAVIA\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Salta":
                numero_loc['text'] = "90"
                valor_pro = ' SALTA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tartagal":
                numero_loc['text'] = "91"
                valor_pro = ' TARTAGAL_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Jachal":
                numero_loc['text'] = "92"
                valor_pro = ' JACHAL\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Juan":
                numero_loc['text'] = "93"
                valor_pro = ' SAN_JUAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Luis":
                numero_loc['text'] = "94"
                valor_pro = ' SAN_LUIS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Rosa del Conlara":
                numero_loc['text'] = "95"
                valor_pro = ' SANTA_ROSA_DE_CONLARA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Villa Reynolds":
                numero_loc['text'] = "96"
                valor_pro = ' VILLA_REYNOLDS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Calafate":
                numero_loc['text'] = "97"
                valor_pro = ' EL_CALAFATE_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Gobernador Gregores":
                numero_loc['text'] = "98"
                valor_pro = ' GOBERNADOR_GREGORES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Perito Moreno":
                numero_loc['text'] = "99"
                valor_pro = ' PERITO_MORENO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Puerto Deseado":
                numero_loc['text'] = "100"
                valor_pro = ' PUERTO_DESEADO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Gallegos":
                numero_loc['text'] = "101"
                valor_pro = ' RIO_GALLEGOS_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "San Julián":
                numero_loc['text'] = "102"
                valor_pro = ' SAN_JULIAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Cruz":
                numero_loc['text'] = "103"
                valor_pro = ' SANTA_CRUZ_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ceres":
                numero_loc['text'] = "104"
                valor_pro = ' CERES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "El Trébol":
                numero_loc['text'] = "105"
                valor_pro = ' EL_TREBOL\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Rafaela":
                numero_loc['text'] = "106"
                valor_pro = ' RAFAELA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Reconquista":
                numero_loc['text'] = "107"
                valor_pro = ' RECONQUISTA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Rosario":
                numero_loc['text'] = "108"
                valor_pro = ' ROSARIO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santa Fe":
                numero_loc['text'] = "109"
                valor_pro = ' SAUCE_VIEJO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Sunchales":
                numero_loc['text'] = "110"
                valor_pro = ' SUNCHALES_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Venado Tuerto":
                numero_loc['text'] = "111"
                valor_pro = ' VENADO_TUERTO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Termas de Rio Hondo":
                numero_loc['text'] = "112"
                valor_pro = ' TERMAS_DE_RIO_HONDO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Santiago del Estero":
                numero_loc['text'] = "113"
                valor_pro = ' SANTIAGO_DEL_ESTERO_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Río Grande B.A.":
                numero_loc['text'] = "114"
                valor_pro = ' RIO_GRANDE_B.A.\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Ushuaia":
                numero_loc['text'] = "115"
                valor_pro = ' USHUAIA_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Tucumán":
                numero_loc['text'] = "116"
                valor_pro = ' TUCUMAN_AERO\n'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Belgrano II":
                numero_loc['text'] = "117"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Esperanza":
                numero_loc['text'] = "118"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Carlini":
                numero_loc['text'] = "119"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Marambio":
                numero_loc['text'] = "120"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base Orcadas":
                numero_loc['text'] = "121"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
            elif x == "Base San Martín":
                numero_loc['text'] = "122"
                valor_pro = 'error'  # este valor corresponde a la busqueda en pronostico
                                     # coloco la palabra error que no existe en la lista para que me lleve al else

                #numero_loc['text'] = "50"  # vacio para generar un espacio
            valor_localidad = numero_loc['text']
            valor_localidad = int(valor_localidad)
            #valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico

            datos1 = (datos[valor_localidad])
            print(datos1)


            
            fecha_texto_1['text'] = dia_hoy
            loc_texto_2['text'] = datos1[0]
            med_texto_5['text'] = datos1[2] + " Hs."
            max_texto_6['text'] = datos1[5] + "º"
            hum_texto_8['text'] = "Humedad: " + datos1[7] + "%"
            term_texto_9['text'] = "Sen.Termica: " + datos1[6]
            atm_texto_10['text'] = "P.Atm: " + datos1[9]
            cielo_texto_11['text'] = datos1[3]
            vis_texto_12['text'] = "Visibilidad: " + datos1[4]
            viento_texto_15['text'] = "Viento: " + datos1[8] + "km."
            data_mañana_19['text'] = dia_mañana
            data_pasado_20['text'] = dia_pasado
            data_pasado2_21['text'] = dia_pasado2

            if float(datos1[5]) < 5:
                Imagmuchofrio2 = Label(ventanaclima, image=muchofrio).place(x=280, y=850, height=12, width=127)

            elif float(datos1[5]) >5 and float(datos1[5]) <= 13:
                Imagfrio2 = Label(ventanaclima, image=frio).place(x=280, y=850, height=12, width=127)

            elif float(datos1[5]) >13 and float(datos1[5]) <= 21:
                Imagfresco2 = Label(ventanaclima, image=fresco).place(x=280, y=850, height=12, width=127)

            elif float(datos1[5]) >21 and float(datos1[5]) <= 25:
                Imagtemp2 = Label(ventanaclima, image=templado).place(x=280, y=850, height=12, width=127)

            elif float(datos1[5]) >25 and float(datos1[5]) <= 32:
                Imagcalor2 = Label(ventanaclima, image=calor).place(x=280, y=850, height=12, width=127)

            elif float(datos1[5]) >32:
                Imagmuchocalor2 = Label(ventanaclima, image=muchocalor).place(x=280, y=850, height=12, width=127)

                    

            # /////////////////////////////// pronostico listbox///////////////////////

            print(" hasta aca")
            urlpro = 'https://ssl.smn.gob.ar/dpd/zipopendata.php?dato=pron5d'
            wget.download(urlpro)
            shutil.unpack_archive(namepro1)  # descomprime el zip
            os.remove(namepro1)  # borra el archivo zip descargado
            # lee datos del txt

            with open("pronostico_5dias" + fechaActual1 + ".txt") as pronostico:
                lines = pronostico.readlines()

            large_str = ''  # define variable de la linea agregada
            for line in lines:  # genera la lista
                large_str += line.rstrip()  # agrega una linea al bucle

            os.remove("pronostico_5dias" + fechaActual1 + ".txt")

            valor = valor_pro  # variable de busque de localidad

            if (valor in lines) == True:
                print("el valor es igual a ", valor)
                vlinea = lines.index(valor)
                print("el numero de linea es", vlinea)
                x1 = vlinea + 10
                x2 = vlinea + 18
                x3 = vlinea + 26

                locx = lines[vlinea]  # localidad
                primeralinea = lines[x1]
                segundalinea = lines[x2]
                terceralinea = lines[x3]
                print(locx)
                print(primeralinea)
                print(segundalinea)
                print(terceralinea)

                print("Fecha:", primeralinea[0:13])
                mañana_texto_16['text'] = primeralinea[0:13]
                print("Hora:", primeralinea[14:19])
                hora_16['text'] = primeralinea[14:19]
                print("Temperatura", primeralinea[27:31])
                maxpro_25['text'] = primeralinea[27:31]
                print("Dir.Viento:", primeralinea[38:41])
                datoviento_25['text'] = primeralinea[38:41]
                print("Velocidad del viento:", primeralinea[44:47], "Km/H")
                veldato_25['text'] = primeralinea[44:47]
                print("Precipitacion", primeralinea[54:60])
                prec_1['text'] = primeralinea[54:60]
                pre1 = primeralinea[54:60]
                pre1 = float(pre1)

       

                if pre1 <= 0.0:
                    mañanacielo['text'] = "Despejado"
                    solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=900, height=100, width=118)
                    print("Despejado")
                elif pre1 > 0.0 and pre1 <= 0.3:
                    mañanacielo['text'] = "Soleado con nubes"
                    algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=900, height=100,
                                                                                             width=118)
                    print("Soleado con nubes")
                elif pre1 > 0.3 and pre1 <= 0.5:
                    mañanacielo['text'] = "Nublado"
                    nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=900, height=100, width=118)
                    print("Nublado")
                elif pre1 > 0.5 and pre1 <= 1.5:
                    mañanacielo['text'] = "Lluvia muy débil"
                    lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=900,
                                                                                                      height=100,
                                                                                                      width=118)
                    print("Lluvia muy débil")
                elif pre1 > 1.5 and pre1 <= 2:
                    mañanacielo['text'] = "Lluvia débil"
                    lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=900, height=100,
                                                                                                width=118)
                    print("Lluvia débil")
                elif pre1 > 2 and pre1 <= 6.5:
                    mañanacielo['text'] = "Lluvia ligera"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                    print("Lluvia ligera")
                elif pre1 > 6.5 and pre1 <= 16:
                    mañanacielo['text'] = "Lluvia moderada"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                    print("Lluvia moderada")
                elif pre1 > 16 and pre1 <= 40:
                    mañanacielo['text'] = "Lluvia fuerte"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
                    print("Lluvia fuerte")
                elif pre1 > 40 and pre1 <= 100:
                    mañanacielo['text'] = "Lluvia torrencial"
                    torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=900, height=100,
                                                                                         width=118)
                    print("Lluvia torrencial")
                elif pre1 > 100 and pre1 <= 250:
                    mañanacielo['text'] = "Torrencial y prob.granizo"
                    granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=900, height=100, width=118)
                    print("Torrencial y prob.granizo")
                elif pre1 > 250:
                    mañanacielo['text'] = "Granizo de gran tamaño"
                    peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=900, height=100,
                                                                                           width=118)
                    print("Granizo de gran tamaño")

                print("")
                print("Fecha:", segundalinea[0:13])
                pasado_texto_17['text'] = segundalinea[0:13]
                print("Hora:", segundalinea[14:19])
                hora_17['text'] = segundalinea[14:19]
                print("Temperatura", segundalinea[27:31])
                maxpro_26['text'] = segundalinea[27:31]
                print("Dir.Viento:", segundalinea[38:41])
                datoviento_26['text'] = segundalinea[38:41]
                print("Velocidad del viento:", segundalinea[44:47], "Km/H")
                veldato_26['text'] = segundalinea[44:47]
                print("Precipitacion", segundalinea[54:60])
                prec_2['text'] = segundalinea[54:60]
                seg1 = segundalinea[54:60]
                seg1 = float(seg1)
                if seg1 <= 0.0:
                    pasadocielo1['text'] = "Despejado"
                    solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1050, height=100, width=118)
                    print("Despejado")
                elif seg1 > 0.0 and seg1 <= 0.3:
                    pasadocielo1['text'] = "Soleado con nubes"
                    algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1050, height=100,
                                                                                             width=118)
                    print("Soleado con nubes")
                elif seg1 > 0.3 and seg1 <= 0.5:
                    pasadocielo1['text'] = "Nublado"
                    nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1050, height=100, width=118)
                    print("Nublado")
                elif seg1 > 0.5 and seg1 <= 1.5:
                    pasadocielo1['text'] = "Lluvia muy débil"
                    lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1050,
                                                                                                      height=100,
                                                                                                      width=118)
                    print("Lluvia muy débil")
                elif seg1 > 1.5 and seg1 <= 2:
                    pasadocielo1['text'] = "Lluvia débil"
                    lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1050, height=100,
                                                                                                width=118)
                    print("Lluvia débil")
                elif seg1 > 2 and seg1 <= 6.5:
                    pasadocielo1['text'] = "Lluvia ligera"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100,
                                                                                      width=118)
                    print("Lluvia ligera")
                elif seg1 > 6.5 and seg1 <= 16:
                    pasadocielo1['text'] = "Lluvia moderada"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100,
                                                                                      width=118)
                    print("Lluvia moderada")
                elif seg1 > 16 and seg1 <= 40:
                    pasadocielo1['text'] = "Lluvia fuerte"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100,
                                                                                      width=118)
                    print("Lluvia fuerte")
                elif seg1 > 40 and seg1 <= 100:
                    pasadocielo1['text'] = "Lluvia torrencial"
                    torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1050, height=100,
                                                                                         width=118)
                    print("Lluvia torrencial")
                elif seg1 > 100 and seg1 <= 250:
                    pasadocielo1['text'] = "Torrencial y prob.granizo"
                    granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1050, height=100, width=118)
                    print("Torrencial y prob.granizo")
                elif seg1 > 250:
                    pasadocielo1['text'] = "Granizo de gran tamaño"
                    peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1050, height=100,
                                                                                           width=118)
                    print("Granizo de gran tamaño")


           

                print("")
                print("Fecha:", terceralinea[0:13])
                pasado2_texto_18['text'] = terceralinea[0:13]
                print("Hora:", terceralinea[14:19])
                hora_18['text'] = terceralinea[14:19]
                print("Temperatura", terceralinea[27:31])
                maxpro_27['text'] = terceralinea[27:31]
                print("Dir.Viento:", terceralinea[38:41])
                datoviento_27['text'] = terceralinea[38:41]
                print("Velocidad del viento:", terceralinea[44:47], "Km/H")
                veldato_27['text'] = terceralinea[44:47]
                print("Precipitacion", terceralinea[54:60])
                prec_3['text'] = terceralinea[54:60]
                ter1 = terceralinea[54:60]
                ter1 = float(ter1)
                if ter1 <= 0.0:
                    pasadocielo2['text'] = "Despejado"
                    solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1200, height=100, width=118)
                    print("Despejado")
                elif ter1 > 0.0 and ter1 <= 0.3:
                    pasadocielo2['text'] = "Soleado con nubes"
                    algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1200, height=100,
                                                                                             width=118)
                    print("Soleado con nubes")
                elif ter1 > 0.3 and ter1 <= 0.5:
                    pasadocielo2['text'] = "Nublado"
                    nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1200, height=100, width=118)
                    print("Nublado")
                elif ter1 > 0.5 and ter1 <= 1.5:
                    pasadocielo2['text'] = "Lluvia muy débil"
                    lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1200,
                                                                                                      height=100,
                                                                                                      width=118)
                    print("Lluvia muy débil")
                elif ter1 > 1.5 and ter1 <= 2:
                    pasadocielo2['text'] = "Lluvia débil"
                    lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1200, height=100,
                                                                                                width=118)
                    print("Lluvia débil")
                elif ter1 > 2 and ter1 <= 6.5:
                    pasadocielo2['text'] = "Lluvia ligera"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100,
                                                                                      width=118)
                    print("Lluvia ligera")
                elif ter1 > 6.5 and ter1 <= 16:
                    pasadocielo2['text'] = "Lluvia moderada"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100,
                                                                                      width=118)
                    print("Lluvia moderada")
                elif ter1 > 16 and ter1 <= 40:
                    pasadocielo2['text'] = "Lluvia fuerte"
                    lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100,
                                                                                      width=118)
                    print("Lluvia fuerte")
                elif ter1 > 40 and ter1 <= 100:
                    pasadocielo2['text'] = "Lluvia torrencial"
                    torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1200, height=100,
                                                                                         width=118)
                    print("Lluvia torrencial")
                elif ter1 > 100 and ter1 <= 250:
                    pasadocielo2['text'] = "Torrencial y prob.granizo"
                    granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1200, height=100, width=118)
                    print("Torrencial y prob.granizo")
                elif ter1 > 250:
                    pasadocielo2['text'] = "Granizo de gran tamaño"
                    peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1200, height=100,
                                                                                           width=118)
                    print("Granizo de gran tamaño")

            else:

                mañana_texto_16['text'] = "......"
                hora_16['text'] = "......"
                maxpro_25['text'] = "......"
                datoviento_25['text'] = "......"
                veldato_25['text'] = "......"
                prec_1['text'] = "......"

                pasado_texto_17['text'] ="......"
                hora_17['text'] ="......"
                maxpro_26['text'] ="......"
                datoviento_26['text'] ="......"
                veldato_26['text'] ="......"
                prec_2['text'] = "......"

                pasado2_texto_18['text'] ="......"
                hora_18['text'] ="......"
                maxpro_27['text'] ="......"
                datoviento_27['text'] ="......"
                veldato_27['text'] ="......"
                prec_3['text'] ="......"

                print("no es igual a ", valor)
            # ////////////////////// fin pronostico codigo inicial

            global cubierto2box
            global electrica2box
            global llovisnabox   
            global solbox
            global cielobox
            global algonubladobox
            
            if "lluv" in cielo_texto_11['text'] :
                llovisnabox = PhotoImage(file="lluvia2.png")
                Imagen2 = Label(ventanaclima, image=llovisnabox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="lluvia.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "Lluv" in cielo_texto_11['text'] :
                llovisnabox = PhotoImage(file="lluvia2.png")
                Imagen2 = Label(ventanaclima, image=llovisnabox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="lluvia.png")
                Imagen113 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)

            elif "elec" in cielo_texto_11['text'] :
                electrica2box = PhotoImage(file="electrica2.png")
                Imagen2 = Label(ventanaclima, image=electrica2box).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="electrica.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "Elec" in cielo_texto_11['text'] :
                electrica2box = PhotoImage(file="electrica2.png")
                Imagen2 = Label(ventanaclima, image=electrica2box).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="electrica.png")
                Imagen113 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)

            elif "Par" in cielo_texto_11['text'] :
                algonubladobox = PhotoImage(file="algonublado.png")
                Imagen2 = Label(ventanaclima, image=algonubladobox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="parcialmente.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "par" in cielo_texto_11['text'] :
                algonubladobox = PhotoImage(file="algonublado.png")
                Imagen2 = Label(ventanaclima, image=algonubladobox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="parcialmente.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "sol" in cielo_texto_11['text'] :
                solbox = PhotoImage(file="sol.png")
                Imagen2 = Label(ventanaclima, image=solbox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="soleado.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)
               

            elif "Sol" in cielo_texto_11['text'] :
                solbox = PhotoImage(file="sol.png")
                Imagen2 = Label(ventanaclima, image=solbox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="soleado.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)
                

            elif "cub" in cielo_texto_11['text'] :
                cubierto2box = PhotoImage(file="cubierto2.png")
                Imagen2 = Label(ventanaclima, image=cubierto2box).place(x=30, y=370, height=161, width=209)
                cielobox= PhotoImage(file="cubierto.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "Cub" in cielo_texto_11['text'] :
                 
                cubierto2box = PhotoImage(file="cubierto2.png")
                Imagen2 = Label(ventanaclima, image=cubierto2box).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="cubierto.png")
                Imagen1 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "nub" in cielo_texto_11['text'] :
                
                algonubladobox = PhotoImage(file="algonublado.png")
                Imagen24 = Label(ventanaclima, image=algonubladobox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="nublado.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "Nub" in cielo_texto_11['text'] :
                
                algonubladobox = PhotoImage(file="algonublado.png")
                Imagen2 = Label(ventanaclima, image=algonubladobox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="nublado.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)

            elif "desp" in cielo_texto_11['text'] :
                solbox = PhotoImage(file="sol.png")
                Imagen2 = Label(ventanaclima, image=solbox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="fotonube2.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)
                

            elif "Desp" in cielo_texto_11['text'] :
                solbox = PhotoImage(file="sol.png")
                Imagen2 = Label(ventanaclima, image=solbox).place(x=30, y=370, height=161, width=209)
                cielobox = PhotoImage(file="fotonube2.png")
                Imagen113 = Label(ventanaclima, image=cielobox).place(x=0, y=0, height=350, width=500)
                
                    
                # *********************** fin clima parte superior ********************************
                




    window = Window(ventanaclima)
    # ******************************** FINAL LISTBOX  CODIGO INICIAL *******************
    
    # ********************************** CLIMA INICIAL *************************************

   
    clima_x = datos1[3]
    print("clima_x", clima_x)
    if "lluv" in clima_x:
         
         llovisna = PhotoImage(file="lluvia2.png")
         Imagen2 = Label(ventanaclima, image=llovisna).place(x=30, y=370, height=161, width=209)
         cielo = PhotoImage(file="lluvia.png")
         Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "Lluv" in clima_x:
         
         llovisna = PhotoImage(file="lluvia2.png")
         Imagen2 = Label(ventanaclima, image=llovisna).place(x=30, y=370, height=161, width=209)
         cielo = PhotoImage(file="lluvia.png")
         Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "elec" in clima_x:
        
        electrica2 = PhotoImage(file="electrica2.png")
        Imagen2 = Label(ventanaclima, image=electrica2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="electrica.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "Elec" in clima_x:
        
        electrica2 = PhotoImage(file="electrica2.png")
        Imagen2 = Label(ventanaclima, image=electrica2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="electrica.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "Par" in clima_x:
        
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="parcialmente.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "par" in clima_x:
        
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="parcialmente.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
    elif "sol" in clima_x:
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="soleado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Sol" in clima_x:
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="soleado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
      
    elif "cub" in clima_x:
        cubierto2 = PhotoImage(file="cubierto2.png")
        Imagen2 = Label(ventanaclima, image=cubierto2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="cubierto.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Cub" in clima_x:
        cubierto2 = PhotoImage(file="cubierto2.png")
        Imagen2 = Label(ventanaclima, image=cubierto2).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="cubierto.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "nub" in clima_x:
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="nublado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Nub" in clima_x:
        algonublado = PhotoImage(file="algonublado.png")
        Imagen2 = Label(ventanaclima, image=algonublado).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="nublado.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "desp" in clima_x:
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="fotonube2.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
    elif "Desp" in clima_x:
        sol = PhotoImage(file="sol.png")
        Imagen2 = Label(ventanaclima, image=sol).place(x=30, y=370, height=161, width=209)
        cielo = PhotoImage(file="fotonube2.png")
        Imagen1 = Label(ventanaclima, image=cielo).place(x=0, y=0, height=350, width=500)
        
        # *********************** fin clima parte superior ********************************
   
    print(" ")
    print("Localidad:", datos1[0])
    print("Fecha:", datos1[1])
    print("hora de medicion", datos1[2])
    print("cielo", datos1[3])
    print("visibilidad", datos1[4])
    print("Temp.Maxima", datos1[5])
    print("Sensacion Termica", datos1[6])
    print("humedad", datos1[7], "%")
    print("viento", datos1[8], "kmh")
    print("presion Atmosferica", datos1[9])
    print("")


    fecha_texto_1['text'] = dia_hoy
    loc_texto_2['text'] = datos1[0]
    med_texto_5['text'] = datos1[2] + " Hs."
    max_texto_6['text'] = datos1[5] + "º"
    hum_texto_8['text'] = "Humedad: " + datos1[7] + "%"
    term_texto_9['text'] = "Sen.Termica: " + datos1[6]
    atm_texto_10['text'] = "P.Atm: " + datos1[9]
    cielo_texto_11['text'] = datos1[3]
    vis_texto_12['text'] = "Visibilidad: " + datos1[4]
    viento_texto_15['text'] = "Viento: " + datos1[8] + "km."
    data_mañana_19['text'] = dia_mañana
    data_pasado_20['text'] = dia_pasado
    data_pasado2_21['text'] = dia_pasado2



    if float(datos1[5]) < 5:
        Imagmuchofrio = Label(ventanaclima, image=muchofrio).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) >5 and float(datos1[5]) <= 13:
        Imagfrio = Label(ventanaclima, image=frio).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) >13 and float(datos1[5]) <= 21:
        Imagfresco = Label(ventanaclima, image=fresco).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) > 21and float(datos1[5]) <= 25:
        Imagtemp = Label(ventanaclima, image=templado).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) > 25 and float(datos1[5]) <= 32:
        Imagcalor = Label(ventanaclima, image=calor).place(x=280, y=850, height=12, width=127)

    elif float(datos1[5]) > 32:
        Imagmuchocalor = Label(ventanaclima, image=muchocalor).place(x=280, y=850, height=12, width=127)



    os.remove(archivo.name)  # borra el archivo txt descomprimido

    #////////////////////////////////////////////////////////////////////////// pronostico

    valor_pro = ' BUENOS_AIRES\n'  # este valor corresponde a la busqueda en pronostico

    with open("pronostico_5dias" + fechaActual1 + ".txt") as pronostico:
        lines = pronostico.readlines()

    large_str = ''  # define variable de la linea agregada
    for line in lines:  # genera la lista
        large_str += line.rstrip()  # agrega una linea al bucle

    valor = valor_pro  # variable de busque de localidad

    if (valor in lines) == True:
        print("el valor es igual a ", valor)
        vlinea = lines.index(valor)
        print("el numero de linea es", vlinea)
        x1 = vlinea + 10
        x2 = vlinea + 18
        x3 = vlinea + 26

        locx = lines[vlinea]  # localidad
        primeralinea = lines[x1]
        segundalinea = lines[x2]
        terceralinea = lines[x3]
        print(locx)
        print(primeralinea)
        print(segundalinea)
        print(terceralinea)

        print("Fecha:", primeralinea[0:13])
        mañana_texto_16['text'] = primeralinea[0:13]
        print("Hora:", primeralinea[14:19])
        hora_16['text'] =primeralinea[14:19]
        print("Temperatura", primeralinea[27:31])
        maxpro_25['text'] =primeralinea[27:31]
        print("Dir.Viento:", primeralinea[38:41])
        datoviento_25['text'] =primeralinea[38:41]
        print("Velocidad del viento:", primeralinea[44:47], "Km/H")
        veldato_25['text'] =primeralinea[44:47]
        print("Precipitacion", primeralinea[54:60])
        prec_1['text'] =primeralinea[54:60]
        pre1 = primeralinea[54:60]
        pre1 = float(pre1)



        if pre1 <= 0.0:
            mañanacielo['text'] ="Despejado"
            solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=900, height=100, width=118)
            print("Despejado")
        elif pre1 > 0.0 and pre1 <= 0.3:
            mañanacielo['text'] ="Soleado con nubes"
            algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=900, height=100, width=118)
            print("Soleado con nubes")
        elif pre1 > 0.3 and pre1 <= 0.5:
            mañanacielo['text'] ="Nublado"
            nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=900, height=100, width=118)
            print("Nublado")
        elif pre1 > 0.5 and pre1 <= 1.5:
            mañanacielo['text'] ="Lluvia muy débil"
            lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=900, height=100, width=118)
            print("Lluvia muy débil")
        elif pre1 > 1.5 and pre1 <= 2:
            mañanacielo['text'] ="Lluvia débil"
            lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=900, height=100, width=118)
            print("Lluvia débil")
        elif pre1 > 2 and pre1 <= 6.5:
            mañanacielo['text'] ="Lluvia ligera"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
            print("Lluvia ligera")
        elif pre1 > 6.5 and pre1 <= 16:
            mañanacielo['text'] ="Lluvia moderada"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
            print("Lluvia moderada")
        elif pre1 > 16 and pre1 <= 40:
            mañanacielo['text'] ="Lluvia fuerte"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=900, height=100, width=118)
            print("Lluvia fuerte")
        elif pre1 > 40 and pre1 <= 100:
            mañanacielo['text'] ="Lluvia torrencial"
            torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=900, height=100, width=118)
            print("Lluvia torrencial")
        elif pre1 > 100 and pre1 <= 250:
            mañanacielo['text'] ="Torrencial y prob.granizo"
            granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=900, height=100, width=118)
            print("Torrencial y prob.granizo")
        elif pre1 > 250:
            mañanacielo['text'] ="Granizo de gran tamaño"
            peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=900, height=100, width=118)
            print("Granizo de gran tamaño")

        print("")
        print("Fecha:", segundalinea[0:13])
        pasado_texto_17['text'] = segundalinea[0:13]
        print("Hora:", segundalinea[14:19])
        hora_17['text'] =segundalinea[14:19]
        print("Temperatura", segundalinea[27:31])
        maxpro_26['text'] = segundalinea[27:31]
        print("Dir.Viento:", segundalinea[38:41])
        datoviento_26['text']=segundalinea[38:41]
        print("Velocidad del viento:", segundalinea[44:47], "Km/H")
        veldato_26['text'] =segundalinea[44:47]
        print("Precipitacion", segundalinea[54:60])
        prec_2['text'] =segundalinea[54:60]
        seg1 = segundalinea[54:60]
        seg1 = float(seg1)
        if seg1 <= 0.0:
            pasadocielo1['text'] = "Despejado"
            solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1050, height=100, width=118)
            print("Despejado")
        elif seg1 > 0.0 and seg1 <= 0.3:
            pasadocielo1['text'] ="Soleado con nubes"
            algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1050, height=100, width=118)
            print("Soleado con nubes")
        elif seg1 > 0.3 and seg1 <= 0.5:
            pasadocielo1['text'] ="Nublado"
            nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1050, height=100, width=118)
            print("Nublado")
        elif seg1 > 0.5 and seg1 <= 1.5:
            pasadocielo1['text'] ="Lluvia muy débil"
            lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia muy débil")
        elif seg1 > 1.5 and seg1 <= 2:
            pasadocielo1['text'] ="Lluvia débil"
            lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia débil")
        elif seg1 > 2 and seg1 <= 6.5:
            pasadocielo1['text'] ="Lluvia ligera"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia ligera")
        elif seg1 > 6.5 and seg1 <= 16:
            pasadocielo1['text'] ="Lluvia moderada"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia moderada")
        elif seg1 > 16 and seg1 <= 40:
            pasadocielo1['text'] ="Lluvia fuerte"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia fuerte")
        elif seg1 > 40 and seg1 <= 100:
            pasadocielo1['text'] ="Lluvia torrencial"
            torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1050, height=100, width=118)
            print("Lluvia torrencial")
        elif seg1 > 100 and seg1 <= 250:
            pasadocielo1['text'] ="Torrencial y prob.granizo"
            granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1050, height=100, width=118)
            print("Torrencial y prob.granizo")
        elif seg1 > 250:
            pasadocielo1['text'] ="Granizo de gran tamaño"
            peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1050, height=100, width=118)
            print("Granizo de gran tamaño")


        print("")
        print("Fecha:", terceralinea[0:13])
        pasado2_texto_18['text'] = terceralinea[0:13]
        print("Hora:", terceralinea[14:19])
        hora_18['text'] =terceralinea[14:19]
        print("Temperatura", terceralinea[27:31])
        maxpro_27['text'] = terceralinea[27:31]
        print("Dir.Viento:", terceralinea[38:41])
        datoviento_27['text'] =terceralinea[38:41]
        print("Velocidad del viento:", terceralinea[44:47], "Km/H")
        veldato_27['text'] =terceralinea[44:47]
        print("Precipitacion", terceralinea[54:60])
        prec_3['text'] =terceralinea[54:60]
        ter1 = terceralinea[54:60]
        ter1 = float(ter1)
        if ter1 <= 0.0:
            pasadocielo2['text'] ="Despejado"
            solproimage1 = Label(ventanaclima, image=solpro).place(x=80, y=1200, height=100, width=118)
            print("Despejado")
        elif ter1 > 0.0 and ter1 <= 0.3:
            pasadocielo2['text'] ="Soleado con nubes"
            algocubiertoproimage1 = Label(ventanaclima, image=algocubiertopro).place(x=80, y=1200, height=100, width=118)
            print("Soleado con nubes")
        elif ter1 > 0.3 and ter1 <= 0.5:
            pasadocielo2['text'] ="Nublado"
            nubladoproimage1 = Label(ventanaclima, image=nubladopro).place(x=80, y=1200, height=100, width=118)
            print("Nublado")
        elif ter1 > 0.5 and ter1 <= 1.5:
            pasadocielo2['text'] ="Lluvia muy débil"
            lluviasmuylevesproproimage1 = Label(ventanaclima, image=lluviasmuylevespro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia muy débil")
        elif ter1 > 1.5 and ter1 <= 2:
            pasadocielo2['text'] ="Lluvia débil"
            lluviaslevesproproimage1 = Label(ventanaclima, image=lluviaslevespro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia débil")
        elif ter1 > 2 and ter1 <= 6.5:
            pasadocielo2['text'] ="Lluvia ligera"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia ligera")
        elif ter1 > 6.5 and ter1 <= 16:
            pasadocielo2['text'] ="Lluvia moderada"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia moderada")
        elif ter1 > 16 and ter1 <= 40:
            pasadocielo2['text'] ="Lluvia fuerte"
            lluviasproproimage1 = Label(ventanaclima, image=lluviaspro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia fuerte")
        elif ter1 > 40 and ter1 <= 100:
            pasadocielo2['text'] ="Lluvia torrencial"
            torrencialproimage1 = Label(ventanaclima, image=torrencialpro).place(x=80, y=1200, height=100, width=118)
            print("Lluvia torrencial")
        elif ter1 > 100 and ter1 <= 250:
            pasadocielo2['text'] ="Torrencial y prob.granizo"
            granizoproimage1 = Label(ventanaclima, image=granizopro).place(x=80, y=1200, height=100, width=118)
            print("Torrencial y prob.granizo")
        elif ter1 > 250:
            pasadocielo2['text'] ="Granizo de gran tamaño"
            peligrogranizoimage1 = Label(ventanaclima, image=peligrogranizo).place(x=80, y=1200, height=100, width=118)
            print("Granizo de gran tamaño")

    else:

            mañana_texto_16['text'] = "......"
            hora_16['text'] = "......"
            maxpro_25['text'] = "......"
            datoviento_25['text'] = "......"
            veldato_25['text'] = "......"
            prec_1['text'] = "......"

            pasado_texto_17['text'] ="......"
            hora_17['text'] ="......"
            maxpro_26['text'] ="......"
            datoviento_26['text'] ="......"
            veldato_26['text'] ="......"
            prec_2['text'] = "......"

            pasado2_texto_18['text'] ="......"
            hora_18['text'] ="......"
            maxpro_27['text'] ="......"
            datoviento_27['text'] ="......"
            veldato_27['text'] ="......"
            prec_3['text'] ="......"
                    
            print("no es igual a ", valor)

    os.remove("pronostico_5dias" + fechaActual1 + ".txt")
    #/////////////////////////////////////// fin pronostico //////////////////////////////////////////////
    while True:
        if localtime().tm_min==int(1000) :
            print ("actualizado")
        else    :
             ventanaclima.mainloop()
    
    #ventanaclima.mainloop()
root.mainloop()

